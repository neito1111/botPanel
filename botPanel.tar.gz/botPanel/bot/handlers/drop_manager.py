from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any
import time

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InputMediaPhoto, Message, ReplyKeyboardRemove
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError

from bot.callbacks import FormEditCb
from bot.config import Settings
from bot.keyboards import (
    DEFAULT_BANKS,
    kb_back,
    kb_dm_back_cancel_inline,
    kb_dm_back_to_menu_inline,
    kb_dm_bank_select_inline,
    kb_dm_done_inline,
    kb_dm_edit_bank_select_inline,
    kb_dm_edit_done_inline,
    kb_dm_edit_actions_inline,
    kb_dm_edit_screens_inline,
    kb_dm_main_inline,
    kb_dm_payment_card_with_back,
    kb_dm_shift_comment_inline,
    kb_dm_source_pick_inline,
    kb_dm_traffic_type_inline,
    kb_dm_forms_filter_menu,
    kb_dm_my_forms_list,
    kb_dm_my_form_open,
    kb_dm_duplicate_bank_phone_inline,
    kb_edit_open,
    kb_edit_fields,
    kb_form_confirm,
    kb_form_confirm_with_edit,
    kb_tl_duplicate_notice,
    kb_traffic_type,
    kb_traffic_type_with_back,
    kb_yes_no,
    kb_back_with_main,
)
from bot.middlewares import GroupMessageFilter
from bot.models import Form, FormStatus, Shift, UserRole
from bot.repositories import (
    create_bank,
    create_duplicate_report,
    create_form,
    delete_form,
    ensure_default_banks,
    list_team_lead_ids_by_source,
    end_shift,
    get_active_shift,
    get_bank,
    get_bank_by_name,
    get_forward_group_by_id,
    get_form,
    get_user_by_id,
    get_user_by_tg_id,
    find_forms_by_phone,
    phone_bank_duplicate_exists,
    list_dm_approved_without_payment,
    list_user_forms_in_range,
    list_rejected_forms_by_user_id,
    count_rejected_forms_by_user_id,
    mark_form_payment_done,
    start_shift,
)
from bot.states import (
    DropManagerEditStates,
    DropManagerFormStates,
    DropManagerRejectedStates,
    DropManagerShiftStates,
    DropManagerMyFormsStates,
    DropManagerPaymentStates,
)
from bot.utils import (
    extract_forward_payload,
    format_timedelta_seconds,
    format_user_payload,
    is_valid_phone,
    normalize_phone,
    pop_dm_approved_notices,
    pop_dm_reject_notice,
    register_tl_duplicate_notice,
    register_tl_form_notice,
)

router = Router(name="drop_manager")
# Apply group message filter to all handlers in this router
router.message.filter(GroupMessageFilter())
log = logging.getLogger(__name__)

_album_ack_tasks: dict[tuple[int, str], asyncio.Task] = {}
_album_counts: dict[tuple[int, str], int] = {}
_album_last_sent_ts: dict[tuple[int, str], float] = {}


def _format_payment_phone(phone: str | None) -> str:
    if not phone:
        return "—"
    return normalize_phone(phone)


def _normalize_card(s: str) -> str:
    return "".join(ch for ch in (s or "") if ch.isdigit())


def _period_to_range(period: str | None) -> tuple[datetime | None, datetime | None]:
    p = (period or "today").lower()
    now = datetime.utcnow()
    today = now.date()
    if p == "all":
        return None, None
    if p == "today":
        start = datetime(today.year, today.month, today.day)
        return start, start + timedelta(days=1)
    if p == "yesterday":
        start = datetime(today.year, today.month, today.day) - timedelta(days=1)
        return start, start + timedelta(days=1)
    if p == "last7":
        end = datetime(today.year, today.month, today.day) + timedelta(days=1)
        return end - timedelta(days=7), end
    if p == "last30":
        end = datetime(today.year, today.month, today.day) + timedelta(days=1)
        return end - timedelta(days=30), end
    if p == "week":
        start_date = today - timedelta(days=today.weekday())
        start = datetime(start_date.year, start_date.month, start_date.day)
        return start, start + timedelta(days=7)
    if p == "month":
        start = datetime(today.year, today.month, 1)
        if today.month == 12:
            end = datetime(today.year + 1, 1, 1)
        else:
            end = datetime(today.year, today.month + 1, 1)
        return start, end
    if p == "prev_month":
        if today.month == 1:
            start = datetime(today.year - 1, 12, 1)
            end = datetime(today.year, 1, 1)
        else:
            start = datetime(today.year, today.month - 1, 1)
            end = datetime(today.year, today.month, 1)
        return start, end
    if p == "year":
        start = datetime(today.year, 1, 1)
        end = datetime(today.year + 1, 1, 1)
        return start, end
    return None, None


async def _send_shift_report_to_forward_group(*, bot: Any, session: AsyncSession, user: Any, report: str) -> None:
    group_id = getattr(user, "forward_group_id", None)
    if not group_id:
        try:
            await bot.send_message(int(user.tg_id), "Группа пересылки не привязана — отчет не отправлен. Попросите разработчика привязать группу.")
        except Exception:
            pass
        return
    g = await get_forward_group_by_id(session, int(group_id))
    if not g:
        try:
            await bot.send_message(int(user.tg_id), "Группа пересылки не найдена — отчет не отправлен. Попросите разработчика перепривязать группу.")
        except Exception:
            pass
        return
    try:
        await bot.send_message(int(g.chat_id), report, parse_mode="HTML")
    except Exception:
        try:
            await bot.send_message(int(user.tg_id), "Не удалось отправить отчет в группу. Проверьте, что бот добавлен в группу и имеет права.")
        except Exception:
            pass


async def _best_effort_cleanup_recent_messages(*, bot: Any, chat_id: int, around_message_id: int | None, limit: int = 80) -> None:
    if not around_message_id:
        return
    start = max(1, int(around_message_id) - int(limit))
    end = int(around_message_id)
    for mid in range(end, start - 1, -1):
        try:
            await bot.delete_message(chat_id=chat_id, message_id=mid)
        except Exception:
            continue


async def _load_my_forms(session: AsyncSession, *, user_id: int, state: FSMContext) -> list[Form]:
    data = await state.get_data()
    period = (data.get("my_forms_period") or "today")
    if period == "custom":
        created_from = data.get("my_forms_created_from")
        created_to = data.get("my_forms_created_to")
        return await list_user_forms_in_range(session, user_id=user_id, created_from=created_from, created_to=created_to)
    created_from, created_to = _period_to_range(period)
    return await list_user_forms_in_range(session, user_id=user_id, created_from=created_from, created_to=created_to)


async def _render_my_forms(cq_or_msg: Message | CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    u = cq_or_msg.from_user
    if not u:
        return
    user = await get_user_by_tg_id(session, u.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    forms = await _load_my_forms(session, user_id=user.id, state=state)
    await state.set_state(DropManagerMyFormsStates.forms_list)
    await state.update_data(my_forms=[{"id": int(f.id)} for f in forms])
    header = f"📋 <b>Мои анкеты</b>\n\nВсего: <b>{len(forms)}</b>"
    kb = kb_dm_my_forms_list(forms)
    if isinstance(cq_or_msg, CallbackQuery):
        await cq_or_msg.answer()
        if cq_or_msg.message:
            await _safe_edit_message(message=cq_or_msg.message, text=header, reply_markup=kb)
        return
    await cq_or_msg.answer(header, reply_markup=kb)


async def _upsert_prompt_message(
    *,
    message: Message,
    state: FSMContext,
    state_key: str,
    text: str,
    reply_markup,
) -> None:
    data = await state.get_data()
    msg_id = data.get(state_key)
    if msg_id:
        try:
            await message.bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=int(msg_id),
                text=text,
                reply_markup=reply_markup,
            )
            return
        except Exception:
            pass
    try:
        m = await message.answer(text, reply_markup=reply_markup)
    except TelegramNetworkError:
        return
    await state.update_data(**{state_key: m.message_id})


async def _cleanup_my_form_view(*, bot: Any, chat_id: int, state: FSMContext) -> None:
    data = await state.get_data()
    msg_ids = list(data.get("my_form_msg_ids") or [])
    if not msg_ids:
        return
    for msg_id in msg_ids:
        try:
            await bot.delete_message(chat_id=chat_id, message_id=int(msg_id))
        except Exception:
            continue
    await state.update_data(my_form_msg_ids=[])


async def _cleanup_edit_preview(*, bot: Any, chat_id: int, state: FSMContext) -> None:
    data = await state.get_data()
    msg_ids = list(data.get("dm_edit_preview_msg_ids") or [])
    if not msg_ids:
        return
    for msg_id in msg_ids:
        try:
            await bot.delete_message(chat_id=chat_id, message_id=int(msg_id))
        except Exception:
            continue
    await state.update_data(dm_edit_preview_msg_ids=[])


async def _cleanup_edit_prompt(*, bot: Any, chat_id: int, state: FSMContext) -> None:
    data = await state.get_data()
    msg_id = data.get("dm_edit_prompt_msg_id")
    if not msg_id:
        return
    try:
        await bot.delete_message(chat_id=chat_id, message_id=int(msg_id))
    except Exception:
        pass
    await state.update_data(dm_edit_prompt_msg_id=None)


async def _set_edit_prompt_message(
    *,
    message: Message,
    state: FSMContext,
    text: str,
    reply_markup,
) -> None:
    await _cleanup_edit_prompt(bot=message.bot, chat_id=int(message.chat.id), state=state)
    try:
        sent = await message.answer(text, reply_markup=reply_markup)
    except TelegramNetworkError:
        return
    await state.update_data(dm_edit_prompt_msg_id=sent.message_id)


async def _send_album_ack(
    *,
    bot: Any,
    chat_id: int,
    accepted: int,
    total: int,
    expected: int | None,
    reply_markup,
) -> None:
    if accepted <= 0:
        return
    if expected and expected > 0:
        text = f"✅ Принято {accepted} фото (итого {total}/{expected})."
    else:
        text = f"✅ Принято {accepted} фото (итого {total})."
    try:
        await bot.send_message(chat_id, text, reply_markup=reply_markup)
    except TelegramNetworkError:
        log.info("Album ack failed (network). chat_id=%s accepted=%s total=%s expected=%s", chat_id, accepted, total, expected)
        return


def _schedule_album_ack(
    *,
    bot: Any,
    chat_id: int,
    media_group_id: str,
    accepted_total: int,
    expected: int | None,
    reply_markup,
) -> None:
    key = (chat_id, media_group_id)
    # avoid duplicate acks if Telegram delivers late updates
    last_ts = _album_last_sent_ts.get(key)
    if last_ts and (time.time() - last_ts) < 2.0:
        return
    prev = _album_ack_tasks.get(key)
    if prev and not prev.done():
        prev.cancel()

    async def _runner() -> None:
        try:
            await asyncio.sleep(1.6)
        except asyncio.CancelledError:
            return
        accepted = _album_counts.pop(key, 0)
        _album_last_sent_ts[key] = time.time()
        await _send_album_ack(
            bot=bot,
            chat_id=chat_id,
            accepted=accepted,
            total=accepted_total,
            expected=expected,
            reply_markup=reply_markup,
        )

    _album_ack_tasks[key] = asyncio.create_task(_runner())


async def _render_dm_menu(message_or_cq: Message | CallbackQuery, session: AsyncSession) -> None:
    if isinstance(message_or_cq, CallbackQuery):
        u = message_or_cq.from_user
        chat_id = message_or_cq.message.chat.id if message_or_cq.message else None
    else:
        u = message_or_cq.from_user
        chat_id = message_or_cq.chat.id

    if not u or chat_id is None:
        return

    user = await get_user_by_tg_id(session, u.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return

    if not user.manager_tag:
        if isinstance(message_or_cq, CallbackQuery):
            await message_or_cq.answer("Сначала введите тег менеджера", show_alert=True)
        else:
            await message_or_cq.answer("Сначала введите тег менеджера")
        return

    shift = await get_active_shift(session, user.id)
    src = getattr(user, "manager_source", None) or "—"
    text = (
        f"👤 <b>Дроп‑менеджер</b>: <b>{user.manager_tag}</b>\n"
        f"Источник: <b>{src}</b>\n"
        f"Смена: <b>{'активна' if shift else 'не активна'}</b>"
    )
    kb = await _build_dm_main_kb(session=session, user_id=int(user.id), shift_active=bool(shift))

    try:
        m = await (message_or_cq.message if isinstance(message_or_cq, CallbackQuery) else message_or_cq).answer(
            "...",
            reply_markup=ReplyKeyboardRemove(),
        )
        await m.delete()
    except Exception:
        pass

    if isinstance(message_or_cq, CallbackQuery):
        await message_or_cq.answer()
        if message_or_cq.message:
            try:
                await message_or_cq.message.answer(text, reply_markup=kb)
            except Exception:
                pass
            try:
                await message_or_cq.message.delete()
            except Exception:
                pass
        return

    await message_or_cq.answer(text, reply_markup=kb)


async def _build_dm_main_kb(*, session: AsyncSession, user_id: int, shift_active: bool) -> InlineKeyboardMarkup:
    if not shift_active:
        return kb_dm_main_inline(shift_active=False)
    rejected_count = await count_rejected_forms_by_user_id(session, user_id)
    return kb_dm_main_inline(shift_active=True, rejected_count=rejected_count)


def _kb_dm_approved_no_pay_list_inline(forms: list[Form]) -> InlineKeyboardBuilder:
    b = InlineKeyboardBuilder()
    for f in forms[:30]:
        bank = f.bank_name or "—"
        b.button(text=f"✅ #{int(f.id)} {bank}", callback_data=f"dm:approved_no_pay_open:{int(f.id)}")
    b.button(text="⬅️ Назад", callback_data="dm:menu")
    b.adjust(1)
    return b


async def _render_dm_approved_no_pay(cq_or_msg: Message | CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    u = cq_or_msg.from_user
    if not u:
        return
    user = await get_user_by_tg_id(session, u.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    notice_ids = pop_dm_approved_notices(int(user.tg_id))
    if notice_ids:
        for msg_id in notice_ids:
            try:
                await cq_or_msg.bot.delete_message(chat_id=int(user.tg_id), message_id=int(msg_id))
            except Exception:
                pass
    forms = await list_dm_approved_without_payment(session, manager_user_id=int(user.id), limit=30)
    header = f"✅ <b>Подтверждённые без номеров</b>\n\nВсего: <b>{len(forms)}</b>"
    kb = _kb_dm_approved_no_pay_list_inline(forms).as_markup()
    await state.update_data(dm_approved_no_pay_ids=[int(f.id) for f in forms])

    if isinstance(cq_or_msg, CallbackQuery):
        await cq_or_msg.answer()
        if cq_or_msg.message:
            await _safe_edit_message(message=cq_or_msg.message, text=header, reply_markup=kb)
        return
    await cq_or_msg.answer(header, reply_markup=kb)


async def _send_form_preview_only(*, bot: Any, chat_id: int, text: str, photos: list[str]) -> None:
    photos = list(photos or [])
    if not photos:
        await bot.send_message(chat_id, text, parse_mode="HTML")
        return
    photos = photos[:10]
    if len(photos) == 1:
        await bot.send_photo(chat_id, photos[0], caption=text, parse_mode="HTML")
        return
    media: list[InputMediaPhoto] = [InputMediaPhoto(media=photos[0], caption=text, parse_mode="HTML")]
    media.extend(InputMediaPhoto(media=p) for p in photos[1:])
    await bot.send_media_group(chat_id, media)


async def _finish_payment(
    *,
    message: Message,
    session: AsyncSession,
    state: FSMContext,
    form: Form,
    payment_text: str | list[str],
) -> None:
    user = await get_user_by_tg_id(session, message.from_user.id)
    manager_tag = (getattr(user, "manager_tag", None) or "—") if user else "—"
    try:
        form_text = _format_form_text(form, manager_tag)
    except Exception:
        form_text = f"📄 <b>Анкета</b>\nID: <code>{form.id}</code>"

    try:
        await _send_form_preview_only(
            bot=message.bot,
            chat_id=int(message.chat.id),
            text=form_text,
            photos=list(form.screenshots or []),
        )
    except Exception:
        pass

    try:
        if isinstance(payment_text, list):
            for item in payment_text:
                await message.answer(item, parse_mode="HTML")
        else:
            await message.answer(payment_text, parse_mode="HTML")
    except Exception:
        pass

    try:
        await message.answer(
            "Вам успешно подтвердили анкету, в случае ошибки веденых данных карты и данных анкет, "
            "вы несете отвественость."
        )
    except Exception:
        pass

    await mark_form_payment_done(session, form_id=int(form.id))
    await state.clear()

    forms_left = await list_dm_approved_without_payment(session, manager_user_id=int(user.id) if user else 0, limit=30)
    if forms_left:
        await _render_dm_approved_no_pay(message, session, state)
        return
    await _render_dm_menu(message, session)


async def _edit_text_or_caption(message: Message, text: str, reply_markup=None) -> None:
    try:
        if message.photo or message.document or message.video:
            await message.edit_caption(caption=text, parse_mode="HTML", reply_markup=reply_markup)
        else:
            await message.edit_text(text, reply_markup=reply_markup)
    except Exception:
        # best effort
        pass


async def _safe_edit_message(*, message: Message, text: str, reply_markup=None) -> None:
    """Edit message text/caption when possible; otherwise send a new message.

    Needed because Telegram doesn't allow edit_text for media-only messages.
    """
    try:
        if getattr(message, "text", None):
            await message.edit_text(text, reply_markup=reply_markup)
            return
    except Exception:
        pass

    try:
        # Works for photos/videos/documents (and also for text messages with captions)
        await message.edit_caption(caption=text, parse_mode="HTML", reply_markup=reply_markup)
        return
    except Exception:
        pass

    await message.answer(text, reply_markup=reply_markup)


def _kb_dm_rejected_list_inline(forms: list[Form]) -> InlineKeyboardBuilder:
    b = InlineKeyboardBuilder()
    for f in forms[:30]:
        b.button(text=f"❌ #{f.id}", callback_data=f"dm:rej:{int(f.id)}")
    b.button(text="⬅️ Назад", callback_data="dm:menu")
    b.adjust(3, 3, 3, 3, 3, 3, 1)
    return b


def _kb_dm_rejected_detail_inline(form_id: int) -> InlineKeyboardBuilder:
    b = InlineKeyboardBuilder()
    b.button(text="Редактировать", callback_data=f"drop_edit_form:{form_id}")
    b.button(text="⬅️ Назад", callback_data="dm:rejected")
    b.adjust(1)
    return b


def _format_form_text(form: Form, manager_tag: str) -> str:
    traffic = "—"
    if form.traffic_type == "DIRECT":
        traffic = "Прямой"
    elif form.traffic_type == "REFERRAL":
        traffic = "Сарафан"

    status_line = "❌ <b>Не подтверждена</b>"
    if form.status == FormStatus.APPROVED:
        status_line = "✅ <b>Подтверждено тим лидом</b>"
    if form.status == FormStatus.REJECTED:
        status_line = "❌ <b>Отклонено</b>"

    ref_line = (
        f"Привел: {format_user_payload(form.referral_user)}\n"
        if form.traffic_type == "REFERRAL"
        else ""
    )

    tl_comment = (form.team_lead_comment or "").strip() or "Комментария нет"
    tl_comment_line = f"Комментарий TL: <b>{tl_comment}</b>\n" if form.status == FormStatus.REJECTED else ""
    return (
        f"{status_line}\n\n"
        "📄 <b>Анкета</b>\n"
        f"ID: <code>{form.id}</code>\n"
        f"Тег менеджера: <b>{manager_tag}</b>\n"
        f"Тип клиента: <b>{traffic}</b>\n"
        f"Клиент: {format_user_payload(form.direct_user)}\n"
        f"{ref_line}"
        f"{tl_comment_line}"
        f"Номер: <code>{form.phone or '—'}</code>\n"
        f"Банк: <b>{form.bank_name or '—'}</b>\n"
        f"Пароль: <code>{form.password or '—'}</code>\n"
        f"Комментарий: {form.comment or '—'}"
    )


async def _send_form_photos(message_or_bot: Any, chat_id: int, photos: list[str]) -> None:
    if not photos:
        return
    if len(photos) == 1:
        try:
            await message_or_bot.send_photo(chat_id, photos[0])
        except TelegramNetworkError:
            return
        return
    media = [InputMediaPhoto(media=p) for p in photos[:10]]
    try:
        await message_or_bot.send_media_group(chat_id, media)
    except TelegramNetworkError:
        return


async def _send_form_preview_with_keyboard(
    *,
    bot: Any,
    chat_id: int,
    text: str,
    photos: list[str],
    reply_markup,
    state: FSMContext | None = None,
    buttons_text: str = "Выберите действие:",
) -> None:
    """
    Send form preview with buttons in a separate message.
    - 0 photos: text, then buttons as separate message
    - 1 photo: photo with caption, then buttons as separate message
    - 2+ photos: album with caption, then buttons as separate message
    """
    photos = photos[:10]
    if not photos:
        try:
            if state:
                await _cleanup_edit_preview(bot=bot, chat_id=chat_id, state=state)
            main_msg = await bot.send_message(chat_id, text, parse_mode="HTML")
            buttons_msg = await bot.send_message(chat_id, buttons_text, reply_markup=reply_markup, parse_mode="HTML")
            if state:
                await state.update_data(dm_edit_preview_msg_ids=[main_msg.message_id, buttons_msg.message_id])
        except TelegramNetworkError:
            return
        return
    if len(photos) == 1:
        try:
            if state:
                await _cleanup_edit_preview(bot=bot, chat_id=chat_id, state=state)
            main_msg = await bot.send_photo(chat_id, photos[0], caption=text, parse_mode="HTML")
            buttons_msg = await bot.send_message(chat_id, buttons_text, reply_markup=reply_markup, parse_mode="HTML")
            if state:
                await state.update_data(dm_edit_preview_msg_ids=[main_msg.message_id, buttons_msg.message_id])
        except TelegramNetworkError:
            return
        return

    # Multiple photos: send album with caption, then buttons as a separate message
    media: list[InputMediaPhoto] = [InputMediaPhoto(media=photos[0], caption=text, parse_mode="HTML")]
    media.extend(InputMediaPhoto(media=p) for p in photos[1:])
    try:
        if state:
            await _cleanup_edit_preview(bot=bot, chat_id=chat_id, state=state)
        album_msgs = await bot.send_media_group(chat_id, media)
        buttons_msg = await bot.send_message(chat_id, buttons_text, reply_markup=reply_markup, parse_mode="HTML")
        if state:
            album_ids = [int(m.message_id) for m in (album_msgs or [])]
            await state.update_data(dm_edit_preview_msg_ids=[*album_ids, buttons_msg.message_id])
    except TelegramNetworkError:
        return


async def _after_dm_edit_show_form(*, message: Message, session: AsyncSession, state: FSMContext, form: Form) -> None:
    user = await get_user_by_tg_id(session, message.from_user.id) if message.from_user else None
    manager_tag = (user.manager_tag if user and user.manager_tag else "—")
    try:
        text = _format_form_text(form, manager_tag)
    except Exception:
        text = f"📄 <b>Анкета</b>\nID: <code>{form.id}</code>"
    photos = list(form.screenshots or [])

    await _cleanup_edit_prompt(bot=message.bot, chat_id=int(message.chat.id), state=state)

    if form.status == FormStatus.IN_PROGRESS:
        await state.set_state(DropManagerFormStates.confirm)
        await state.update_data(form_id=form.id)
        await _send_form_preview_with_keyboard(
            bot=message.bot,
            chat_id=int(message.chat.id),
            text=text,
            photos=photos,
            reply_markup=kb_form_confirm_with_edit(form.id),
            state=state,
        )
        return

    await state.set_state(DropManagerEditStates.choose_field)
    await state.update_data(form_id=form.id)
    await _send_form_preview_with_keyboard(
        bot=message.bot,
        chat_id=int(message.chat.id),
        text=text,
        photos=photos,
        reply_markup=kb_dm_edit_actions_inline(form.id),
        state=state,
    )


async def _send_photos_simple(message_or_bot: Any, chat_id: int, photos: list[str]) -> None:
    if not photos:
        return
    if len(photos) == 1:
        try:
            await message_or_bot.send_photo(chat_id, photos[0])
        except TelegramNetworkError:
            return
        return
    media = [InputMediaPhoto(media=p) for p in photos[:10]]
    try:
        await message_or_bot.send_media_group(chat_id, media)
    except TelegramNetworkError:
        return


async def _send_photos_with_caption(message_or_bot: Any, chat_id: int, photos: list[str], caption: str) -> None:
    """
    Sends as:
    - 1 photo => send_photo(caption)
    - 2+ photos => send_media_group(first has caption)
    """
    if not photos:
        return
    photos = photos[:10]
    if len(photos) == 1:
        try:
            await message_or_bot.send_photo(chat_id, photos[0], caption=caption, parse_mode="HTML")
        except TelegramNetworkError:
            return
        return
    media: list[InputMediaPhoto] = [InputMediaPhoto(media=photos[0], caption=caption, parse_mode="HTML")]
    media.extend(InputMediaPhoto(media=p) for p in photos[1:])
    try:
        await message_or_bot.send_media_group(chat_id, media)
    except TelegramNetworkError:
        return


async def _get_bank_instructions_text(session: AsyncSession, *, user: User | None, bank_name: str) -> str | None:
    bank = await get_bank_by_name(session, bank_name)
    if not bank:
        return None
    src = (getattr(user, "manager_source", None) or "").upper() if user else ""
    instructions_src = None
    if src == "FB":
        instructions_src = getattr(bank, "instructions_fb", None)
    elif src == "TG":
        instructions_src = getattr(bank, "instructions_tg", None)
    instructions = (instructions_src or getattr(bank, "instructions", None) or "").strip()
    if not instructions:
        return None
    return f"📌 <b>Условия ({bank.name})</b>:\n<blockquote expandable>{instructions or '—'}</blockquote>"


async def _notify_team_leads_new_form(
    bot: Any,
    settings: Settings,
    session: AsyncSession,
    form: Form,
    manager_tag: str,
) -> None:
    # route by manager source (TG/FB) using DB-backed team leads
    src = "TG"
    try:
        if getattr(form, "manager", None) and getattr(form.manager, "manager_source", None):
            src = (form.manager.manager_source or "TG").upper() or "TG"
    except Exception:
        src = "TG"

    tl_ids = await list_team_lead_ids_by_source(session, src)
    if not tl_ids:
        return
    dm = await get_user_by_id(session, form.manager_id)
    dm_username = f"@{dm.username}" if dm and dm.username else "—"
    text = f"От кого заявка: <b>{dm_username}</b>\n\n" + _format_form_text(form, manager_tag)
    for tl_id in tl_ids:
        try:
            bank = getattr(form, "bank_name", None) or "—"
            b = InlineKeyboardBuilder()
            b.button(text="Перейти", callback_data=f"tl:live_open:{int(form.id)}")
            b.adjust(1)
            notice = await bot.send_message(
                tl_id,
                (
                    f"🆕 <b>Анкета {form.id}</b>\n"
                    f"Банк: <b>{bank}</b>\n"
                    f"ДМ: <b>{dm_username}</b>"
                ),
                parse_mode="HTML",
                reply_markup=b.as_markup(),
            )
            register_tl_form_notice(int(tl_id), int(form.id), int(notice.message_id))
        except Exception:
            log.exception("Failed to notify team lead %s", tl_id)


async def _notify_team_leads_duplicate_bank_phone(
    *,
    bot: Any,
    session: AsyncSession,
    dm_user: User,
    phone: str,
    bank_name: str,
) -> None:
    try:
        await create_duplicate_report(
            session,
            manager_id=int(dm_user.id),
            manager_username=dm_user.username,
            manager_source=getattr(dm_user, "manager_source", None),
            phone=phone,
            bank_name=bank_name,
        )
    except Exception:
        pass
    src = (getattr(dm_user, "manager_source", None) or "TG").upper() or "TG"
    tl_ids = await list_team_lead_ids_by_source(session, src)
    if not tl_ids:
        return
    dm_username = f"@{dm_user.username}" if dm_user.username else "—"
    text = (
        "⚠️ Дубликат: Банк+Номер\n"
        f"ДМ: <b>{dm_username}</b>\n"
        f"Номер: <code>{phone}</code>\n"
        f"Банк: <b>{bank_name}</b>"
    )
    for tl_id in tl_ids:
        try:
            notice = await bot.send_message(
                tl_id,
                text,
                parse_mode="HTML",
                reply_markup=kb_tl_duplicate_notice(),
            )
            register_tl_duplicate_notice(int(tl_id), int(notice.message_id))
        except Exception:
            log.exception("Failed to notify team lead %s about duplicate", tl_id)


@router.message(F.text == "Начать работу")
async def start_work(message: Message, session: AsyncSession) -> None:
    # Ignore group messages
    if message.chat.type in ['group', 'supergroup']:
        return
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    if not getattr(user, "forward_group_id", None):
        await message.answer(
            "Сначала разработчик должен привязать вас к группе пересылки.\n"
            "Напишите разработчику и попросите привязать группу.",
            reply_markup=kb_dm_main_inline(shift_active=False),
        )
        return
    if not user.manager_tag:
        await message.answer("Сначала введите тег менеджера:")
        return
    active = await get_active_shift(session, user.id)
    if active:
        kb = await _build_dm_main_kb(session=session, user_id=int(user.id), shift_active=True)
        await message.answer("У вас уже есть активная смена.", reply_markup=kb)
        return
    await start_shift(session, user.id)
    kb = await _build_dm_main_kb(session=session, user_id=int(user.id), shift_active=True)
    await message.answer("✅ Смена начата.", reply_markup=kb)


@router.callback_query(F.data == "dm:menu")
async def dm_menu_cb(cq: CallbackQuery, session: AsyncSession) -> None:
    await _render_dm_menu(cq, session)


@router.callback_query(F.data == "dm:my_forms")
async def dm_my_forms_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
    await _render_my_forms(cq, session, state)


@router.callback_query(F.data.startswith("dm:pay_card:"))
async def dm_pay_card_start_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    try:
        form_id = int((cq.data or "").split(":")[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    # optional: only after TL approval
    if form.status != FormStatus.APPROVED:
        await cq.answer("Доступно только для подтвержденных анкет", show_alert=True)
        return

    if getattr(form, "payment_done_at", None) is not None:
        await cq.answer("Оплата уже заполнена", show_alert=True)
        return

    await cq.answer()
    await state.clear()
    await state.set_state(DropManagerPaymentStates.card_main)
    await state.update_data(pay_form_id=int(form.id), pay_traffic=str(form.traffic_type))
    if cq.message:
        await cq.message.answer("Напишите или перешлите номер карты Прямого клиента за оплату банка")


@router.callback_query(F.data == "dm:approved_no_pay")
async def dm_approved_no_pay_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await _render_dm_approved_no_pay(cq, session, state)


@router.callback_query(F.data.startswith("dm:approved_no_pay_open:"))
async def dm_approved_no_pay_open_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    try:
        form_id = int((cq.data or "").split(":")[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id or form.status != FormStatus.APPROVED:
        await cq.answer("Анкета не найдена", show_alert=True)
        return
    if getattr(form, "payment_done_at", None) is not None:
        await cq.answer("Оплата уже заполнена", show_alert=True)
        return

    await cq.answer()

    manager_tag = user.manager_tag or "—"
    try:
        text = _format_form_text(form, manager_tag)
    except Exception:
        text = f"📄 <b>Анкета</b>\nID: <code>{form.id}</code>"

    try:
        await _send_form_preview_only(
            bot=cq.bot,
            chat_id=int(cq.message.chat.id if cq.message else cq.from_user.id),
            text=text,
            photos=list(form.screenshots or []),
        )
    except Exception:
        pass

    if cq.message:
        await cq.message.answer("Выберите действие:", reply_markup=kb_dm_payment_card_with_back(int(form.id)))


@router.message(DropManagerPaymentStates.card_main, F.text)
async def dm_pay_card_main_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    card = _normalize_card(message.text)
    if len(card) < 12 or len(card) > 19:
        await message.answer("Некорректный номер карты. Введите ещё раз:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data.get("pay_form_id") or 0))
    if not form:
        await state.clear()
        return
    await state.update_data(pay_card_main=card)
    await state.set_state(DropManagerPaymentStates.amount_main)
    await message.answer("Напишите или перешлите сумму оплаты")


@router.message(DropManagerPaymentStates.amount_main, F.text)
async def dm_pay_amount_main_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    amount_raw = (message.text or "").strip().replace(" ", "")
    if not amount_raw.isdigit():
        await message.answer("Некорректная сумма. Введите число:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data.get("pay_form_id") or 0))
    if not form:
        await state.clear()
        return

    card = str(data.get("pay_card_main") or "")
    traffic = (data.get("pay_traffic") or "").split(".")[-1]
    if traffic == "REFERRAL":
        await state.update_data(pay_amount_main=amount_raw)
        await state.set_state(DropManagerPaymentStates.card_bonus)
        await message.answer("Напишите или перешлите номер карты того, кто привёл")
        return

    payment_text = (
        f"Оплата {_format_payment_phone(form.phone)}\n\n"
        f"{card}\n\n"
        f"{amount_raw}"
    )
    await _finish_payment(message=message, session=session, state=state, form=form, payment_text=payment_text)
    return


@router.message(DropManagerPaymentStates.phone_bonus, F.text)
async def dm_pay_phone_bonus_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    if not is_valid_phone(message.text):
        await message.answer("Некорректный номер телефона. Пример: <code>944567892</code> или <code>+380991112233</code>")
        return
    data = await state.get_data()
    form = await get_form(session, int(data.get("pay_form_id") or 0))
    if not form:
        await state.clear()
        return
    phone = normalize_phone(message.text)
    await state.update_data(pay_phone_bonus=phone)
    await state.set_state(DropManagerPaymentStates.card_bonus)
    await message.answer("Напишите или перешлите номер карты того, кто привёл")


@router.message(DropManagerPaymentStates.card_bonus, F.text)
async def dm_pay_card_bonus_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    card = _normalize_card(message.text)
    if len(card) < 12 or len(card) > 19:
        await message.answer("Некорректный номер карты. Введите ещё раз:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data.get("pay_form_id") or 0))
    if not form:
        await state.clear()
        return
    await state.update_data(pay_card_bonus=card)
    await state.set_state(DropManagerPaymentStates.amount_bonus)
    await message.answer("Напишите или перешлите сумму оплаты")


@router.message(DropManagerPaymentStates.amount_bonus, F.text)
async def dm_pay_amount_bonus_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    amount_raw = (message.text or "").strip().replace(" ", "")
    if not amount_raw.isdigit():
        await message.answer("Некорректная сумма. Введите число:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data.get("pay_form_id") or 0))
    if not form:
        await state.clear()
        return

    card_bonus = str(data.get("pay_card_bonus") or "")
    card_main = str(data.get("pay_card_main") or "")
    amount_main = str(data.get("pay_amount_main") or "")
    payment_text = [
        (
            f"Оплата {_format_payment_phone(form.phone)}\n\n"
            f"{card_main}\n\n"
            f"{amount_main}"
        ),
        (
            f"Бонус {_format_payment_phone(form.phone)}\n\n"
            f"{card_bonus}\n\n"
            f"{amount_raw}"
        ),
    ]

    await _finish_payment(message=message, session=session, state=state, form=form, payment_text=payment_text)


@router.callback_query(F.data == "dm:my_forms_filter")
async def dm_my_forms_filter_menu_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    data = await state.get_data()
    current = (data.get("my_forms_period") or "today")
    if cq.message:
        await cq.message.edit_text("📅 <b>Фильтр моих анкет</b>", reply_markup=kb_dm_forms_filter_menu(current=current))


@router.callback_query(F.data.startswith("dm:my_forms_filter_set:"))
async def dm_my_forms_filter_set_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    period = (cq.data or "").split(":")[-1]
    await state.update_data(my_forms_period=period, my_forms_created_from=None, my_forms_created_to=None)
    await _render_my_forms(cq, session, state)


@router.callback_query(F.data == "dm:my_forms_filter_custom")
async def dm_my_forms_filter_custom_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerMyFormsStates.forms_filter_range)
    if cq.message:
        await cq.message.edit_text("Введите интервал дат в формате: <code>DD.MM.YYYY-DD.MM.YYYY</code>")


@router.message(DropManagerMyFormsStates.forms_filter_range, F.text)
async def dm_my_forms_filter_range_msg(message: Message, session: AsyncSession, state: FSMContext) -> None:
    # Ignore group messages
    if message.chat.type in ['group', 'supergroup']:
        return
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return

    raw = (message.text or "").strip().replace(" ", "")
    if "-" not in raw:
        await message.answer("Неверный формат. Пример: <code>21.01.2026-31.01.2026</code>")
        return
    a, b = raw.split("-", 1)
    try:
        d1 = datetime.strptime(a, "%d.%m.%Y")
        d2 = datetime.strptime(b, "%d.%m.%Y")
    except ValueError:
        await message.answer("Неверный формат. Пример: <code>21.01.2026-31.01.2026</code>")
        return
    if d2 < d1:
        d1, d2 = d2, d1
    created_from = datetime(d1.year, d1.month, d1.day)
    created_to = datetime(d2.year, d2.month, d2.day) + timedelta(days=1)

    await state.update_data(my_forms_period="custom", my_forms_created_from=created_from, my_forms_created_to=created_to)
    await _render_my_forms(message, session, state)


@router.callback_query(F.data.startswith("dm:my_form_open:"))
async def dm_my_form_open_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    try:
        form_id = int((cq.data or "").split(":")[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return
    await cq.answer()
    await state.set_state(DropManagerMyFormsStates.form_view)
    await state.update_data(my_form_id=form_id)

    manager_tag = user.manager_tag or "—"
    try:
        text = _format_form_text(form, manager_tag)
    except Exception:
        text = f"📋 <b>АНКЕТА #{form.id}</b>"

    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        photos = list(form.screenshots or [])
        chat_id = int(cq.message.chat.id)
        in_progress = form.status == FormStatus.IN_PROGRESS
        if photos:
            # Send album with caption, then buttons as separate message
            try:
                media = [InputMediaPhoto(media=photos[0], caption=text, parse_mode="HTML")]
                for photo_id in photos[1:10]:
                    media.append(InputMediaPhoto(media=photo_id))
                album_msgs = await cq.bot.send_media_group(chat_id, media)
                buttons_msg = await cq.bot.send_message(
                    chat_id,
                    "Выберите действие:",
                    reply_markup=kb_dm_my_form_open(form_id, in_progress=in_progress),
                )
                album_ids = [int(m.message_id) for m in (album_msgs or [])]
                await state.update_data(my_form_msg_ids=[*album_ids, buttons_msg.message_id])
                try:
                    await cq.message.delete()
                except Exception:
                    pass
                return
            except TelegramNetworkError:
                pass
            except Exception:
                pass

        # No screenshots (or failed to send): send text, then buttons
        try:
            main_msg = await cq.bot.send_message(chat_id, text, parse_mode="HTML")
            buttons_msg = await cq.bot.send_message(
                chat_id,
                "Выберите действие:",
                reply_markup=kb_dm_my_form_open(form_id, in_progress=form.status == FormStatus.IN_PROGRESS),
            )
            await state.update_data(my_form_msg_ids=[main_msg.message_id, buttons_msg.message_id])
            try:
                await cq.message.delete()
            except Exception:
                pass
        except TelegramNetworkError:
            pass


@router.callback_query(F.data.startswith("dm:my_form_send:"))
async def dm_my_form_send_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext, settings: Settings) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    try:
        form_id = int((cq.data or "").split(":")[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    form.status = FormStatus.PENDING
    form.team_lead_comment = None

    manager_tag = user.manager_tag or "—"
    text = _format_form_text(form, manager_tag)
    await cq.answer("Отправлено")
    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        await _render_dm_menu(cq, session)

    await _notify_team_leads_new_form(cq.bot, settings, session, form, manager_tag)


@router.callback_query(F.data.startswith("dm:my_form_resume:"))
async def dm_my_form_resume_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    form_id = int(cq.data.split(":")[-1])
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id or form.status != FormStatus.IN_PROGRESS:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    await cq.answer()
    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
    await state.clear()
    await state.update_data(form_id=form.id)

    async def _prompt(text: str, reply_markup) -> None:
        if cq.message:
            await _safe_edit_message(message=cq.message, text=text, reply_markup=reply_markup)
        else:
            await cq.bot.send_message(int(cq.from_user.id), text, reply_markup=reply_markup)

    traffic_type = (form.traffic_type or "").upper()
    if not traffic_type:
        await state.set_state(DropManagerFormStates.traffic_type)
        await _prompt("Выберите тип клиента:", kb_dm_traffic_type_inline())
        return

    if traffic_type == "DIRECT":
        if not form.direct_user:
            await state.set_state(DropManagerFormStates.direct_forward)
            await _prompt(
                "Перешлите сообщение клиента (форвард):",
                kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
            )
            return
    if traffic_type == "REFERRAL":
        if not form.direct_user:
            await state.set_state(DropManagerFormStates.referral_forward_1)
            await _prompt(
                "1) Перешлите сообщение клиента (на кого анкета):",
                kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
            )
            return
        if not form.referral_user:
            await state.set_state(DropManagerFormStates.referral_forward_2)
            await _prompt(
                "2) Перешлите сообщение пользователя, который привёл клиента:",
                kb_dm_back_cancel_inline(back_cb="dm:back_to_ref1"),
            )
            return

    if not form.phone:
        await state.set_state(DropManagerFormStates.phone)
        await _prompt(
            "Напишите номер и перешлите его в бота.\nСообщение должно содержать <b>только номер</b> и ничего больше:",
            kb_dm_back_cancel_inline(back_cb="dm:back_to_forward"),
        )
        return

    if not form.bank_name:
        await state.set_state(DropManagerFormStates.bank_select)
        await _prompt("Выберите банк:", kb_dm_bank_select_inline())
        return

    if not form.password:
        await state.set_state(DropManagerFormStates.password)
        instr = await _get_bank_instructions_text(session, user=user, bank_name=form.bank_name or "")
        if instr:
            await cq.bot.send_message(int(cq.from_user.id), instr, parse_mode="HTML")
        if instr:
            await cq.bot.send_message(
                int(cq.from_user.id),
                "Введите пароль/инкод:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
            )
        else:
            await _prompt("Введите пароль/инкод:", kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"))
        return

    if not form.screenshots:
        await state.set_state(DropManagerFormStates.screenshots)
        bank = await get_bank_by_name(session, form.bank_name or "")
        src = (getattr(user, "manager_source", None) or "").upper()
        required = None
        if bank:
            if src == "FB":
                required = getattr(bank, "required_screens_fb", None)
            elif src == "TG":
                required = getattr(bank, "required_screens_tg", None)
            if required is None:
                required = getattr(bank, "required_screens", None)
        await state.update_data(expected_screens=required, collected_screens=[])
        if required and required > 0:
            await _prompt(
                f"Перешлите скрины от банка как на запросе. Нужно <b>{required}</b> фото.\n\n"
                f"Отправьте скрин 1/{required}:",
                kb_dm_done_inline(),
            )
        else:
            await _prompt(
                "Перешлите скрины от банка как на запросе. Когда закончите — нажмите <b>Готово</b>.\n\n"
                "Отправляйте фото:",
                kb_dm_done_inline(),
            )
        return

    if not form.comment:
        await state.set_state(DropManagerFormStates.comment)
        await _prompt("Комментарий к анкете:", kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"))
        return

    await state.set_state(DropManagerFormStates.confirm)
    text = _format_form_text(form, user.manager_tag or "—")
    await _send_form_preview_with_keyboard(
        bot=cq.bot,
        chat_id=int(cq.from_user.id),
        text=text,
        photos=list(form.screenshots or []),
        reply_markup=kb_form_confirm_with_edit(form.id),
        state=state,
    )


@router.callback_query(F.data.startswith("dm:my_form_delete:"))
async def dm_my_form_delete_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    try:
        form_id = int((cq.data or "").split(":")[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    await delete_form(session, form_id)
    await cq.answer("Удалено")
    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
    await _render_my_forms(cq, session, state)


@router.callback_query(F.data == "dm:start_shift")
async def dm_start_shift_cb(cq: CallbackQuery, session: AsyncSession) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    if not getattr(user, "forward_group_id", None):
        await cq.answer("Вас еще не привязали к группе пересылки", show_alert=True)
        if cq.message:
            src = getattr(user, "manager_source", None) or "—"
            await _safe_edit_message(
                message=cq.message,
                text=(
                    f"👤 <b>Дроп‑менеджер</b>: <b>{user.manager_tag or '—'}</b>\n"
                    f"Источник: <b>{src}</b>\n"
                    "Группа пересылки: <b>не привязана</b>\n\n"
                    "Сначала разработчик должен привязать вам группу."
                ),
                reply_markup=kb_dm_main_inline(shift_active=False),
            )
        return
    if not user.manager_tag:
        await cq.answer("Сначала введите тег менеджера", show_alert=True)
        return
    active = await get_active_shift(session, user.id)
    if active:
        await cq.answer("Смена уже активна", show_alert=True)
        return
    await start_shift(session, user.id)
    await cq.answer("✅ Смена начата")
    if cq.message:
        src = getattr(user, "manager_source", None) or "—"
        await _safe_edit_message(
            message=cq.message,
            text=(
                f"👤 <b>Дроп‑менеджер</b>: <b>{user.manager_tag}</b>\n"
                f"Источник: <b>{src}</b>\n"
                "Смена: <b>активна</b>"
            ),
            reply_markup=await _build_dm_main_kb(
                session=session,
                user_id=int(user.id),
                shift_active=True,
            ),
        )


@router.callback_query(F.data == "dm:end_shift")
async def dm_end_shift_prompt_cb(cq: CallbackQuery, session: AsyncSession) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    shift = await get_active_shift(session, user.id)
    if not shift:
        await cq.answer("У вас нет активной смены", show_alert=True)
        if cq.message:
            src = getattr(user, "manager_source", None) or "—"
            await _safe_edit_message(
                message=cq.message,
                text=(
                    f"👤 <b>Дроп‑менеджер</b>: <b>{user.manager_tag or '—'}</b>\n"
                    f"Источник: <b>{src}</b>\n"
                    "Смена: <b>не активна</b>"
                ),
                reply_markup=kb_dm_main_inline(shift_active=False),
            )
        return
    await cq.answer()
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text="После подтверждения вы окончите смену и бот сформирует ваш отчет.",
            reply_markup=kb_yes_no(f"shift_end_confirm:{shift.id}", f"shift_end_cancel:{shift.id}"),
        )


@router.message(F.text == "Закончить работу")
async def end_work_prompt(message: Message, session: AsyncSession) -> None:
    # Ignore group messages
    if message.chat.type in ['group', 'supergroup']:
        return
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    shift = await get_active_shift(session, user.id)
    if not shift:
        await message.answer("У вас нет активной смены.", reply_markup=kb_dm_main_inline(shift_active=False))
        return
    await message.answer(
        "После нажатия кнопки вы окончите смену и бот сформирует ваш отчет.",
        reply_markup=kb_yes_no(f"shift_end_confirm:{shift.id}", f"shift_end_cancel:{shift.id}"),
    )


@router.callback_query(F.data.startswith("shift_end_cancel:"))
async def end_work_cancel(cq: CallbackQuery) -> None:
    await cq.answer("Ок")
    if cq.message:
        await _safe_edit_message(message=cq.message, text="Ок, смена продолжается.")


@router.callback_query(F.data.startswith("shift_end_confirm:"))
async def end_work_confirm(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return

    shift_id = int(cq.data.split(":")[1])
    res = await session.execute(select(Shift).where(Shift.id == shift_id))
    shift = res.scalar_one_or_none()
    if not shift or shift.manager_id != user.id or shift.ended_at is not None:
        await cq.answer("Смена не найдена", show_alert=True)
        return

    await cq.answer()
    await state.set_state(DropManagerShiftStates.dialogs_count)
    await state.update_data(shift_id=shift.id)
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text="Введите количество диалогов за сегодняшний день:",
            reply_markup=None,
        )


async def _finalize_shift_with_comment(
    *,
    session: AsyncSession,
    shift: Shift,
    manager_tag: str,
    manager_username: str | None,
    dialogs_count: int | None,
    comment_of_day: str | None,
) -> str:
    shift.ended_at = datetime.utcnow()
    shift.comment_of_day = (comment_of_day or None)
    shift.dialogs_count = dialogs_count

    duration = int((shift.ended_at - shift.started_at).total_seconds())

    agg = await session.execute(
        select(Form.bank_name, Form.traffic_type, func.count(Form.id))
        .where(Form.shift_id == shift.id)
        .group_by(Form.bank_name, Form.traffic_type)
        .order_by(Form.bank_name.asc())
    )
    rows = list(agg.all())
    bank_map: dict[str, dict[str, int]] = {}
    for bank_name, traffic_type, cnt in rows:
        bn = (bank_name or "—").strip() or "—"
        tt = (traffic_type or "—").strip() or "—"
        bank_map.setdefault(bn, {})[tt] = int(cnt or 0)

    uname = f"@{manager_username}" if manager_username else "—"
    dialogs = str(dialogs_count) if dialogs_count is not None else "—"
    lines: list[str] = [
        "🧾 <b>Отчёт по смене:</b>",
        f"Менеджер - <b>{uname}</b>",
        f"Тег - <b>{manager_tag or '—'}</b>",
        f"Количество диалогов - <b>{dialogs}</b>",
        f"Время в работе - <b>{format_timedelta_seconds(duration)}</b>",
        "",
    ]

    seen = set(bank_map.keys())
    bank_order = [b for b in DEFAULT_BANKS if b in seen] + [b for b in sorted(seen) if b not in DEFAULT_BANKS]
    for bank in bank_order:
        direct = bank_map.get(bank, {}).get("DIRECT", 0)
        referral = bank_map.get(bank, {}).get("REFERRAL", 0)
        if direct == 0 and referral == 0:
            continue
        bank_display = (bank[:1].upper() + bank[1:].lower()) if bank else "—"
        lines.append(f"{bank_display}:")
        lines.append(f"Прямой - <b>{direct}</b>")
        lines.append(f"Сарафан - <b>{referral}</b>")
        lines.append("")

    if lines and lines[-1] == "":
        lines.pop()

    com = (comment_of_day or "").strip() or "—"
    lines.extend(["", "<b>Комментарий дня:</b>", com])
    await session.commit()
    return "\n".join(lines)


@router.callback_query(F.data.startswith("shift_comment_skip:"))
async def dm_shift_comment_skip(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return

    shift_id = int(cq.data.split(":")[1])
    res = await session.execute(select(Shift).where(Shift.id == shift_id))
    shift = res.scalar_one_or_none()
    if not shift or shift.manager_id != user.id or shift.ended_at is not None:
        await cq.answer("Смена не найдена", show_alert=True)
        return

    data = await state.get_data()
    dialogs_count = data.get("dialogs_count")
    report = await _finalize_shift_with_comment(
        session=session,
        shift=shift,
        manager_tag=user.manager_tag or "—",
        manager_username=user.username,
        dialogs_count=int(dialogs_count) if dialogs_count is not None else None,
        comment_of_day=None,
    )

    await _send_shift_report_to_forward_group(bot=cq.bot, session=session, user=user, report=report)
    around_id = int(cq.message.message_id) if cq.message else None
    await _best_effort_cleanup_recent_messages(bot=cq.bot, chat_id=int(cq.from_user.id), around_message_id=around_id, limit=120)

    await state.clear()
    await cq.answer("Смена закрыта")
    if cq.message:
        try:
            await cq.message.delete()
        except Exception:
            pass
        await cq.message.answer(report)
        await cq.message.answer("Главное меню:", reply_markup=kb_dm_main_inline(shift_active=False))


@router.callback_query(F.data.startswith("shift_comment_back:"))
async def dm_shift_comment_back(cq: CallbackQuery, session: AsyncSession) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return

    shift_id = int(cq.data.split(":")[1])
    shift = await get_active_shift(session, user.id)
    if not shift or shift.id != shift_id:
        await cq.answer("Смена не найдена", show_alert=True)
        return

    await cq.answer()
    if cq.message:
        await cq.message.edit_text(
            "После подтверждения вы окончите смену и бот сформирует ваш отчет.",
            reply_markup=kb_yes_no(f"shift_end_confirm:{shift.id}", f"shift_end_cancel:{shift.id}"),
        )


@router.message(DropManagerShiftStates.dialogs_count, F.text)
async def dm_shift_dialogs_count_message(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return

    shift = await get_active_shift(session, user.id)
    if not shift:
        await state.clear()
        await message.answer("У вас нет активной смены.", reply_markup=kb_dm_main_inline(shift_active=False))
        return

    raw = (message.text or "").strip().replace(" ", "")
    if not raw.isdigit():
        await message.answer("Введите число (например: 12)")
        return
    dialogs_count = int(raw)
    await state.update_data(dialogs_count=dialogs_count)
    await state.set_state(DropManagerShiftStates.comment_of_day)
    await message.answer(
        "Введите <b>Комментарий дня</b> (одним сообщением):",
        reply_markup=kb_dm_shift_comment_inline(shift_id=int(shift.id)),
    )
    return


@router.message(DropManagerShiftStates.comment_of_day, F.text)
async def dm_shift_comment_message(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return

    shift = await get_active_shift(session, user.id)
    if not shift:
        await state.clear()
        await message.answer("У вас нет активной смены.", reply_markup=kb_dm_main_inline(shift_active=False))
        return

    txt = (message.text or "").strip()
    if not txt:
        await message.answer("Введите комментарий текстом одним сообщением.")
        return

    data = await state.get_data()
    dialogs_count = data.get("dialogs_count")
    report = await _finalize_shift_with_comment(
        session=session,
        shift=shift,
        manager_tag=user.manager_tag or "—",
        manager_username=user.username,
        dialogs_count=int(dialogs_count) if dialogs_count is not None else None,
        comment_of_day=txt,
    )

    await _send_shift_report_to_forward_group(bot=message.bot, session=session, user=user, report=report)
    await _best_effort_cleanup_recent_messages(bot=message.bot, chat_id=int(message.chat.id), around_message_id=int(message.message_id), limit=120)

    await state.clear()
    await message.answer(report)
    await message.answer("Главное меню:", reply_markup=kb_dm_main_inline(shift_active=False))


@router.message(F.text == "Создать анкету")
async def create_form_entry(message: Message, session: AsyncSession, state: FSMContext) -> None:
    # Ignore group messages
    if message.chat.type in ['group', 'supergroup']:
        return
    if not message.from_user:
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    if not user.manager_tag:
        await message.answer("Сначала введите тег менеджера:")
        return
    shift = await get_active_shift(session, user.id)
    if not shift:
        await message.answer("Сначала нажмите <b>Начать работу</b>.", reply_markup=kb_dm_main_inline(shift_active=False))
        return
    form = await create_form(session, user.id, shift.id)
    await state.set_state(DropManagerFormStates.traffic_type)
    await state.update_data(form_id=form.id)
    await message.answer("Выберите тип клиента:", reply_markup=kb_dm_traffic_type_inline())


@router.callback_query(F.data == "dm:create_form")
async def dm_create_form_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    if not user.manager_tag:
        await cq.answer("Сначала введите тег менеджера", show_alert=True)
        return
    shift = await get_active_shift(session, user.id)
    if not shift:
        await cq.answer("Смена не активна", show_alert=True)
        if cq.message:
            src = getattr(user, "manager_source", None) or "—"
            await cq.message.edit_text(
                f"👤 <b>Дроп‑менеджер</b>: <b>{user.manager_tag}</b>\n"
                f"Источник: <b>{src}</b>\n"
                "Смена: <b>не активна</b>",
                reply_markup=kb_dm_main_inline(shift_active=False),
            )
        return

    form = await create_form(session, user.id, shift.id)
    await state.set_state(DropManagerFormStates.traffic_type)
    await state.update_data(form_id=form.id)
    await cq.answer()
    if cq.message:
        await cq.message.edit_text("Выберите тип клиента:", reply_markup=kb_dm_traffic_type_inline())


@router.callback_query(F.data.startswith("dm:traffic:"))
async def dm_traffic_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    data = await state.get_data()
    form_id = data.get("form_id")
    if not form_id:
        await cq.answer("Нет анкеты", show_alert=True)
        return
    form = await get_form(session, int(form_id))
    if not form:
        await state.clear()
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    choice = cq.data.split(":")[-1]
    if choice == "DIRECT":
        form.traffic_type = "DIRECT"
        form.referral_user = None
        await state.set_state(DropManagerFormStates.direct_forward)
        await cq.answer()
        if cq.message:
            await cq.message.edit_text(
                "Перешлите сообщение клиента (форвард):",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
            )
        return
    if choice == "REFERRAL":
        form.traffic_type = "REFERRAL"
        await state.set_state(DropManagerFormStates.referral_forward_1)
        await cq.answer()
        if cq.message:
            await cq.message.edit_text(
                "1) Перешлите сообщение клиента (на кого анкета):",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
            )
        return

    await cq.answer("Некорректный выбор", show_alert=True)


@router.callback_query(F.data == "dm:back_to_traffic")
async def dm_back_to_traffic_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.traffic_type)
    if cq.message:
        await cq.message.edit_text("Выберите тип клиента:", reply_markup=kb_dm_traffic_type_inline())


@router.callback_query(F.data == "dm:cancel_form")
async def dm_cancel_form_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    data = await state.get_data()
    form_id = data.get("form_id")
    if form_id:
        form = await get_form(session, int(form_id))
        if form:
            await session.delete(form)
    await state.clear()
    await _render_dm_menu(cq, session)


@router.message(DropManagerFormStates.traffic_type, F.text, F.text != "Назад")
async def form_traffic(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    if message.text == "Прямой":
        form.traffic_type = "DIRECT"
        await state.set_state(DropManagerFormStates.direct_forward)
        await message.answer(
            "Перешлите сообщение клиента (форвард):",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
        )
        return
    if message.text == "Сарафан":
        form.traffic_type = "REFERRAL"
        await state.set_state(DropManagerFormStates.referral_forward_1)
        await message.answer(
            "1) Перешлите сообщение клиента (на кого анкета):",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
        )
        return
    await message.answer("Выберите кнопкой: Прямой / Сарафан")


@router.message(DropManagerFormStates.direct_forward, F.text != "Назад")
async def form_direct_forward(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.direct_user = extract_forward_payload(message)
    await state.set_state(DropManagerFormStates.phone)
    await message.answer(
        "Напишите номер и перешлите его в бота.\n"
        "Сообщение должно содержать <b>только номер</b> и ничего больше:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_forward")
    )


@router.message(DropManagerFormStates.referral_forward_1, F.text != "Назад")
async def form_referral_forward_1(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.direct_user = extract_forward_payload(message)
    await state.set_state(DropManagerFormStates.referral_forward_2)
    await message.answer(
        "2) Перешлите сообщение пользователя, который привёл клиента:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_ref1"),
    )


@router.message(DropManagerFormStates.referral_forward_2, F.text != "Назад")
async def form_referral_forward_2(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.referral_user = extract_forward_payload(message)
    await state.set_state(DropManagerFormStates.phone)
    await message.answer(
        "Напишите номер и перешлите его в бота.\n"
        "Сообщение должно содержать <b>только номер</b> и ничего больше:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_forward")
    )


@router.callback_query(F.data == "dm:back_to_ref1")
async def dm_back_to_ref1_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.referral_forward_1)
    if cq.message:
        await cq.message.edit_text(
            "1) Перешлите сообщение клиента (на кого анкета):",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
        )


@router.callback_query(F.data == "dm:back_to_forward")
async def dm_back_to_forward_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form_id = data.get("form_id")
    if not form_id:
        await cq.answer("Нет анкеты", show_alert=True)
        return
    form = await get_form(session, int(form_id))
    if not form:
        await state.clear()
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    await cq.answer()
    if form.traffic_type == "DIRECT":
        await state.set_state(DropManagerFormStates.direct_forward)
        if cq.message:
            await cq.message.edit_text(
                "Перешлите сообщение клиента (форвард):",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
            )
        return
    if form.traffic_type == "REFERRAL":
        await state.set_state(DropManagerFormStates.referral_forward_2)
        if cq.message:
            await cq.message.edit_text(
                "2) Перешлите сообщение пользователя, который привёл клиента:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_ref1"),
            )
        return


@router.message(DropManagerFormStates.phone, F.text)
async def form_phone(message: Message, session: AsyncSession, state: FSMContext) -> None:
    phone_text = message.text.strip()
    if not is_valid_phone(phone_text):
        await message.answer("Сообщение должно содержать только номер. Пример: <code>944567892</code> или <code>+380991112233</code>")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.phone = normalize_phone(phone_text)

    # warn if phone already exists anywhere
    try:
        existing = await find_forms_by_phone(session, form.phone)
        existing = [f for f in existing if int(f.id) != int(form.id)]
        if existing:
            lines: list[str] = []
            for f in existing[:3]:
                other = await get_user_by_id(session, int(f.manager_id))
                other_tag = (other.manager_tag if other and other.manager_tag else "—")
                lines.append(f"- #{f.id} | {f.bank_name or '—'} | {other_tag}")
            more = "" if len(existing) <= 3 else f"\n... и ещё <b>{len(existing) - 3}</b>"
            await message.answer("⚠️ Номер уже встречался в системе:\n" + "\n".join(lines) + more)
    except Exception:
        pass

    await ensure_default_banks(session)
    await state.set_state(DropManagerFormStates.bank_select)
    await message.answer("Выберите банк:", reply_markup=kb_dm_bank_select_inline())


@router.callback_query(F.data == "dm:back_to_phone")
async def dm_back_to_phone_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.phone)
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text=(
                "Напишите номер и перешлите его в бота.\n"
                "Сообщение должно содержать <b>только номер</b> и ничего больше:"
            ),
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_forward"),
        )


@router.callback_query(F.data.startswith("dm:bank:"))
async def dm_bank_pick_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    bank_name = cq.data.split(":", 2)[-1]
    if bank_name not in DEFAULT_BANKS:
        await cq.answer("Некорректный банк", show_alert=True)
        return
    data = await state.get_data()
    form_id = data.get("form_id")
    if not form_id:
        await cq.answer("Нет анкеты", show_alert=True)
        return
    form = await get_form(session, int(form_id))
    if not form:
        await state.clear()
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    form.bank_name = bank_name

    if form.phone:
        dup = await phone_bank_duplicate_exists(
            session,
            phone=str(form.phone),
            bank_name=str(form.bank_name),
            exclude_form_id=int(form.id),
        )
        if dup:
            other = await get_user_by_id(session, int(dup.manager_id))
            other_tag = (other.manager_tag if other and other.manager_tag else "—")
            dm_user = await get_user_by_tg_id(session, cq.from_user.id)
            if dm_user:
                await _notify_team_leads_duplicate_bank_phone(
                    bot=cq.bot,
                    session=session,
                    dm_user=dm_user,
                    phone=str(form.phone),
                    bank_name=str(form.bank_name),
                )
            await state.set_state(DropManagerFormStates.bank_select)
            if cq.message:
                await _safe_edit_message(
                    message=cq.message,
                    text=(
                        "❌ Такой номер уже есть для этого банка.\n"
                        f"Менеджер: <b>{other_tag}</b>, анкета <code>#{dup.id}</code>\n\n"
                        "Выберите действие:"
                    ),
                    reply_markup=kb_dm_duplicate_bank_phone_inline(),
                )
            return

    user = await get_user_by_tg_id(session, cq.from_user.id)
    instr = await _get_bank_instructions_text(session, user=user, bank_name=bank_name)
    await state.set_state(DropManagerFormStates.password)
    await cq.answer()
    if cq.message:
        if instr:
            await cq.bot.send_message(int(cq.from_user.id), instr, parse_mode="HTML")
            await cq.bot.send_message(
                int(cq.from_user.id),
                "Введите пароль/инкод:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
            )
        else:
            await _safe_edit_message(
                message=cq.message,
                text="Введите пароль/инкод:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
            )


@router.callback_query(F.data == "dm:bank_custom")
async def dm_bank_custom_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.bank_custom)
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text="Введите название банка:",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
        )


@router.callback_query(F.data == "dm:back_to_bank_select")
async def dm_back_to_bank_select_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.bank_select)
    if cq.message:
        await _safe_edit_message(message=cq.message, text="Выберите банк:", reply_markup=kb_dm_bank_select_inline())


@router.message(DropManagerFormStates.bank_select, F.text)
async def form_bank_select(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    txt = message.text.strip()
    if txt == "Написать название":
        await state.set_state(DropManagerFormStates.bank_custom)
        await message.answer(
            "Введите название банка:",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
        )
        return
    if txt not in DEFAULT_BANKS:
        await message.answer("Выберите банк кнопкой или нажмите 'Написать название'.")
        return
    form.bank_name = txt

    if form.phone:
        dup = await phone_bank_duplicate_exists(
            session,
            phone=str(form.phone),
            bank_name=str(form.bank_name),
            exclude_form_id=int(form.id),
        )
        if dup:
            other = await get_user_by_id(session, int(dup.manager_id))
            other_tag = (other.manager_tag if other and other.manager_tag else "—")
            dm_user = await get_user_by_tg_id(session, message.from_user.id) if message.from_user else None
            if dm_user:
                await _notify_team_leads_duplicate_bank_phone(
                    bot=message.bot,
                    session=session,
                    dm_user=dm_user,
                    phone=str(form.phone),
                    bank_name=str(form.bank_name),
                )
            await state.set_state(DropManagerFormStates.bank_select)
            await message.answer(
                "❌ Такой номер уже есть для этого банка.\n"
                f"Менеджер: <b>{other_tag}</b>, анкета <code>#{dup.id}</code>\n\n"
                "Выберите действие:",
                reply_markup=kb_dm_duplicate_bank_phone_inline(),
            )
            return

    user = await get_user_by_tg_id(session, message.from_user.id)
    instr = await _get_bank_instructions_text(session, user=user, bank_name=txt)
    await state.set_state(DropManagerFormStates.password)
    if instr:
        await message.answer(instr, parse_mode="HTML")
    await message.answer(
        "Введите пароль/инкод:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
    )


@router.message(DropManagerFormStates.bank_custom, F.text)
async def form_bank_custom(message: Message, session: AsyncSession, state: FSMContext) -> None:
    bank_name = message.text.strip()
    if not bank_name or len(bank_name) > 64:
        await message.answer("Название банка слишком длинное/пустое. Введите ещё раз:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.bank_name = bank_name
    if form.phone:
        dup = await phone_bank_duplicate_exists(
            session,
            phone=str(form.phone),
            bank_name=str(form.bank_name),
            exclude_form_id=int(form.id),
        )
        if dup:
            other = await get_user_by_id(session, int(dup.manager_id))
            other_tag = (other.manager_tag if other and other.manager_tag else "—")
            dm_user = await get_user_by_tg_id(session, message.from_user.id) if message.from_user else None
            if dm_user:
                await _notify_team_leads_duplicate_bank_phone(
                    bot=message.bot,
                    session=session,
                    dm_user=dm_user,
                    phone=str(form.phone),
                    bank_name=str(form.bank_name),
                )
            await state.set_state(DropManagerFormStates.bank_select)
            await message.answer(
                "❌ Такой номер уже есть для этого банка.\n"
                f"Менеджер: <b>{other_tag}</b>, анкета <code>#{dup.id}</code>\n\n"
                "Выберите действие:",
                reply_markup=kb_dm_duplicate_bank_phone_inline(),
            )
            return
    if not await get_bank_by_name(session, bank_name):
        await create_bank(session, bank_name)
    user = await get_user_by_tg_id(session, message.from_user.id)
    instr = await _get_bank_instructions_text(session, user=user, bank_name=bank_name)
    await state.set_state(DropManagerFormStates.password)
    if instr:
        await message.answer(instr, parse_mode="HTML")
    await message.answer(
        "Введите пароль/инкод:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
    )


@router.message(DropManagerFormStates.password, F.text)
async def form_password(message: Message, session: AsyncSession, state: FSMContext) -> None:
    pwd = (message.text or "").strip()
    if not pwd:
        await message.answer("Введите пароль/инкод:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.password = pwd

    bank = await get_bank_by_name(session, form.bank_name or "")
    user = await get_user_by_id(session, form.manager_id)
    src = (getattr(user, "manager_source", None) or "").upper() if user else ""
    required = None
    if bank:
        if src == "FB":
            required = getattr(bank, "required_screens_fb", None)
        elif src == "TG":
            required = getattr(bank, "required_screens_tg", None)
        if required is None:
            required = getattr(bank, "required_screens", None)
    await state.update_data(expected_screens=required, collected_screens=[])
    await state.set_state(DropManagerFormStates.screenshots)

    if required and required > 0:
        await message.answer(
            f"Перешлите скрины от банка как на запросе. Нужно <b>{required}</b> фото.\n\n"
            f"Отправьте скрин 1/{required}:",
            reply_markup=kb_dm_done_inline(),
        )
    else:
        await message.answer(
            "Перешлите скрины от банка как на запросе. Когда закончите — нажмите <b>Готово</b>.\n\n"
            "Отправляйте фото:",
            reply_markup=kb_dm_done_inline(),
        )


@router.callback_query(F.data == "dm:back_to_password")
async def dm_back_to_password_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.password)
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text="Введите пароль/инкод:",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
        )


@router.callback_query(F.data == "dm:screens_done")
async def dm_screens_done_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    collected: list[str] = list(data.get("collected_screens") or [])
    if not collected:
        await cq.answer("Сначала отправьте хотя бы 1 фото.", show_alert=True)
        return
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        await cq.answer("Анкета не найдена", show_alert=True)
        return
    form.screenshots = collected
    await state.set_state(DropManagerFormStates.comment)
    await cq.answer()
    if cq.message:
        await _safe_edit_message(
            message=cq.message,
            text="Комментарий к анкете:",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"),
        )


@router.callback_query(F.data == "dm:back_to_screens")
async def dm_back_to_screens_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    await state.set_state(DropManagerFormStates.screenshots)
    if cq.message:
        data = await state.get_data()
        expected = data.get("expected_screens")
        if expected and int(expected) > 0:
            text = (
                f"Перешлите скрины от банка как на запросе. Нужно <b>{int(expected)}</b> фото.\n\n"
                f"Отправьте следующий скрин:")
        else:
            text = (
                "Перешлите скрины от банка как на запросе. Когда закончите — нажмите <b>Готово</b>.\n\n"
                "Отправляйте фото:")
        await _safe_edit_message(message=cq.message, text=text, reply_markup=kb_dm_done_inline())


@router.message(DropManagerFormStates.screenshots, F.photo)
async def form_screenshot_add(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    expected = data.get("expected_screens")
    collected: list[str] = list(data.get("collected_screens") or [])

    file_id = message.photo[-1].file_id
    media_group_id = getattr(message, "media_group_id", None)
    if media_group_id:
        key = (int(message.chat.id), str(media_group_id))
        _album_counts[key] = _album_counts.get(key, 0) + 1
    if len(collected) < 20:
        collected.append(file_id)
    await state.update_data(collected_screens=collected)

    if expected and expected > 0:
        if len(collected) < expected:
            if media_group_id:
                _schedule_album_ack(
                    bot=message.bot,
                    chat_id=int(message.chat.id),
                    media_group_id=str(media_group_id),
                    accepted_total=len(collected),
                    expected=int(expected),
                    reply_markup=kb_dm_done_inline(),
                )
                return
            await _upsert_prompt_message(
                message=message,
                state=state,
                state_key="screens_prompt_msg_id",
                text=f"Отправьте скрин {len(collected)+1}/{expected}:",
                reply_markup=kb_dm_done_inline(),
            )
            return
        # save to db and move on
        form = await get_form(session, int(data["form_id"]))
        if not form:
            await state.clear()
            return
        form.screenshots = collected
        await state.set_state(DropManagerFormStates.comment)
        try:
            await message.answer(
                "Комментарий к анкете:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"),
            )
        except TelegramNetworkError:
            return
        return

    # free mode (no expected)
    if media_group_id:
        # do a single ack per album
        _schedule_album_ack(
            bot=message.bot,
            chat_id=int(message.chat.id),
            media_group_id=str(media_group_id),
            accepted_total=len(collected),
            expected=None,
            reply_markup=kb_dm_done_inline(),
        )
        if len(collected) >= 20:
            form = await get_form(session, int(data["form_id"]))
            if not form:
                await state.clear()
                return
            form.screenshots = collected
            await state.set_state(DropManagerFormStates.comment)
            try:
                await message.answer(
                    "Комментарий к анкете:",
                    reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"),
                )
            except TelegramNetworkError:
                return
        return
    await _upsert_prompt_message(
        message=message,
        state=state,
        state_key="screens_prompt_msg_id",
        text=f"✅ Скрин {len(collected)} принят. Отправляйте ещё или нажмите <b>Готово</b>.",
        reply_markup=kb_dm_done_inline(),
    )
    if len(collected) >= 20:
        try:
            await message.answer("Достигнут лимит 20 фото. Переходим к комментарию.")
        except TelegramNetworkError:
            return
        form = await get_form(session, int(data["form_id"]))
        if not form:
            await state.clear()
            return
        form.screenshots = collected
        await state.set_state(DropManagerFormStates.comment)
        try:
            await message.answer(
                "Комментарий к анкете:",
                reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"),
            )
        except TelegramNetworkError:
            return


@router.message(DropManagerFormStates.screenshots)
async def form_screenshot_wrong(message: Message) -> None:
    await message.answer("Нужно отправить <b>фото</b> (скрин).")


@router.message(DropManagerFormStates.comment, F.text)
async def form_comment(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.comment = message.text.strip()
    await state.set_state(DropManagerFormStates.confirm)
    user = await get_user_by_tg_id(session, message.from_user.id)
    text = _format_form_text(form, user.manager_tag or "—")
    photos = list(form.screenshots or [])
    await _send_form_preview_with_keyboard(
        bot=message.bot,
        chat_id=int(message.chat.id),
        text=text,
        photos=photos,
        reply_markup=kb_form_confirm_with_edit(form.id),
        state=state,
    )


@router.callback_query(F.data.in_({"form_submit", "form_cancel"}))
async def form_confirm_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext, settings: Settings) -> None:
    data = await state.get_data()
    form_id = data.get("form_id")
    if not form_id:
        await cq.answer("Нет анкеты", show_alert=True)
        return
    form = await get_form(session, int(form_id))
    if not form:
        await state.clear()
        return

    # hard-block duplicate phone+bank
    if cq.data == "form_submit" and form.phone and form.bank_name:
        dup = await phone_bank_duplicate_exists(
            session,
            phone=str(form.phone),
            bank_name=str(form.bank_name),
            exclude_form_id=int(form.id),
        )
        if dup:
            other = await get_user_by_id(session, int(dup.manager_id))
            other_tag = (other.manager_tag if other and other.manager_tag else "—")
            await cq.answer(
                f"❌ Такой номер уже есть для этого банка (менеджер: {other_tag}, анкета #{dup.id})",
                show_alert=True,
            )
            return

    if cq.data == "form_cancel":
        await delete_form(session, int(form_id))
        await state.clear()
        await cq.answer("Отменено")
        if cq.message:
            shift = await get_active_shift(session, form.manager_id)
            await _safe_edit_message(
                message=cq.message,
                text="Анкета отменена.",
                reply_markup=await _build_dm_main_kb(
                    session=session,
                    user_id=int(form.manager_id),
                    shift_active=bool(shift),
                ),
            )
        return

    form.status = FormStatus.PENDING
    await state.clear()

    await cq.answer("Отправлено")
    if cq.message:
        shift = await get_active_shift(session, form.manager_id)
        await _safe_edit_message(
            message=cq.message,
            text="✅ Анкета отправлена тим‑лиду на проверку.",
            reply_markup=await _build_dm_main_kb(
                session=session,
                user_id=int(form.manager_id),
                shift_active=bool(shift),
            ),
        )

    # notify TL
    manager = await get_user_by_tg_id(session, cq.from_user.id)
    await _notify_team_leads_new_form(cq.bot, settings, session, form, manager.manager_tag or "—")


@router.callback_query(FormEditCb.filter(F.action == "open"))
async def edit_open(cq: CallbackQuery, callback_data: FormEditCb, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    form = await get_form(session, callback_data.form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return
    await cq.answer()

    # Remember where edit was opened from so "Назад" returns to the previous menu
    source_text = ""
    try:
        if cq.message and getattr(cq.message, "text", None):
            source_text = str(cq.message.text or "")
        elif cq.message and getattr(cq.message, "caption", None):
            source_text = str(cq.message.caption or "")
    except Exception:
        source_text = ""
    edit_return_mode = "edit_actions"
    if source_text.strip().lower().startswith("выберите действие"):
        edit_return_mode = "my_forms_actions"
    if (cq.data or "").startswith("dm:rej:") or ("отклоненные анкеты" in source_text.strip().lower()):
        edit_return_mode = "rejected_list"
    if "отклонена" in source_text.strip().lower():
        edit_return_mode = "dm_menu"

    notice_id = pop_dm_reject_notice(int(cq.from_user.id), int(form.id))
    if notice_id:
        try:
            await cq.bot.delete_message(chat_id=int(cq.from_user.id), message_id=int(notice_id))
        except Exception:
            pass

    # Keep the form message, just swap inline keyboard to edit-actions
    if cq.message:
        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        await state.clear()
        await state.set_state(DropManagerEditStates.choose_field)
        await state.update_data(form_id=form.id, edit_return_mode=edit_return_mode)
        manager_tag = user.manager_tag or "—"
        text = _format_form_text(form, manager_tag)
        buttons_text = "Выберите действие:"
        if form.status == FormStatus.REJECTED:
            tl_comment = (form.team_lead_comment or "").strip() or "Комментария нет"
            buttons_text = f"Комментарий TL: <b>{tl_comment}</b>\n\n{buttons_text}"
        await _send_form_preview_with_keyboard(
            bot=cq.bot,
            chat_id=int(cq.message.chat.id),
            text=text,
            photos=list(form.screenshots or []),
            reply_markup=kb_dm_edit_actions_inline(form.id),
            buttons_text=buttons_text,
            state=state,
        )
        if edit_return_mode not in {"rejected_list", "dm_menu"}:
            try:
                await cq.message.delete()
            except Exception:
                pass
        return

    await state.clear()
    await state.set_state(DropManagerEditStates.choose_field)
    await state.update_data(form_id=form.id, edit_return_mode=edit_return_mode)


@router.callback_query(F.data.startswith("dm_edit:back:"))
async def dm_edit_back_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    parts = cq.data.split(":")
    form_id = int(parts[-1])
    form = await get_form(session, form_id)
    if not form:
        await state.clear()
        return

    data = await state.get_data()
    edit_return_mode = (data.get("edit_return_mode") or "").strip()

    # If edit was opened from "Мои анкеты" action menu, return back to that menu (without re-sending the form)
    if edit_return_mode == "my_forms_actions":
        await state.set_state(DropManagerMyFormsStates.form_view)
        await state.update_data(my_form_id=form.id)
        if cq.message:
            await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
            await _cleanup_edit_prompt(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
            try:
                await cq.message.delete()
            except Exception:
                pass

        user = await get_user_by_tg_id(session, cq.from_user.id) if cq.from_user else None
        manager_tag = (user.manager_tag if user and user.manager_tag else "—")
        try:
            text = _format_form_text(form, manager_tag)
        except Exception:
            text = f"📄 <b>Анкета</b>\nID: <code>{form.id}</code>"

        await _cleanup_my_form_view(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        photos = list(form.screenshots or [])
        chat_id = int(cq.message.chat.id) if cq.message else int(cq.from_user.id)
        if photos:
            # Send album with caption, then buttons as separate message
            try:
                media = [InputMediaPhoto(media=photos[0], caption=text, parse_mode="HTML")]
                for p in photos[1:10]:
                    media.append(InputMediaPhoto(media=p))
                album_msgs = await cq.bot.send_media_group(chat_id, media)
                buttons_msg = await cq.bot.send_message(
                    chat_id,
                    "Выберите действие:",
                    reply_markup=kb_dm_my_form_open(int(form.id)),
                )
                album_ids = [int(m.message_id) for m in (album_msgs or [])]
                await state.update_data(my_form_msg_ids=[*album_ids, buttons_msg.message_id])
            except Exception:
                # fallback: send text, then buttons as separate messages if album fails
                try:
                    main_msg = await cq.bot.send_message(chat_id, text, parse_mode="HTML")
                    buttons_msg = await cq.bot.send_message(
                        chat_id,
                        "Выберите действие:",
                        reply_markup=kb_dm_my_form_open(int(form.id)),
                    )
                    await state.update_data(my_form_msg_ids=[main_msg.message_id, buttons_msg.message_id])
                except Exception:
                    pass
        else:
            # No photos: send text, then buttons as separate message
            try:
                main_msg = await cq.bot.send_message(chat_id, text, parse_mode="HTML")
                buttons_msg = await cq.bot.send_message(
                    chat_id,
                    "Выберите действие:",
                    reply_markup=kb_dm_my_form_open(int(form.id)),
                )
                await state.update_data(my_form_msg_ids=[main_msg.message_id, buttons_msg.message_id])
            except Exception:
                pass
        return

    if edit_return_mode == "rejected_list":
        if cq.message:
            await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
            await _cleanup_edit_prompt(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        await state.clear()
        await dm_rejected_cb(cq, session, state)
        return

    if edit_return_mode == "dm_menu":
        if cq.message:
            await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
            await _cleanup_edit_prompt(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        await state.clear()
        await _render_dm_menu(cq, session)
        return

    # back target depends on form status: draft -> confirm keyboard, otherwise -> edit-actions
    user = await get_user_by_tg_id(session, cq.from_user.id) if cq.from_user else None
    manager_tag = (user.manager_tag if user and user.manager_tag else "—")
    text = _format_form_text(form, manager_tag)
    chat_id = int(cq.message.chat.id) if cq.message else int(cq.from_user.id)
    await _cleanup_edit_preview(bot=cq.bot, chat_id=chat_id, state=state)
    if cq.message:
        try:
            await cq.message.delete()
        except Exception:
            pass
    if form.status == FormStatus.IN_PROGRESS:
        await state.set_state(DropManagerFormStates.confirm)
        await state.update_data(form_id=form.id)
        await _send_form_preview_with_keyboard(
            bot=cq.bot,
            chat_id=chat_id,
            text=text,
            photos=list(form.screenshots or []),
            reply_markup=kb_form_confirm_with_edit(form.id),
            state=state,
        )
    else:
        await state.set_state(DropManagerEditStates.choose_field)
        await state.update_data(form_id=form.id)
        await _send_form_preview_with_keyboard(
            bot=cq.bot,
            chat_id=chat_id,
            text=text,
            photos=list(form.screenshots or []),
            reply_markup=kb_dm_edit_actions_inline(form.id),
            state=state,
        )


@router.callback_query(F.data == "dm_edit:cancel")
async def dm_edit_cancel_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    if cq.message:
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
    await state.clear()
    try:
        if cq.message:
            await cq.message.delete()
    except Exception:
        pass
    await _render_dm_menu(cq, session)


@router.callback_query(F.data.startswith("dm_edit:resubmit:"))
async def dm_edit_resubmit_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext, settings: Settings) -> None:
    if not cq.from_user:
        return
    parts = cq.data.split(":")
    form_id = int(parts[-1])
    form = await get_form(session, form_id)
    if not form:
        await cq.answer("Анкеты нету", show_alert=True)
        await state.clear()
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER or form.manager_id != user.id:
        await cq.answer("Нет прав", show_alert=True)
        return

    # hard-block duplicate phone+bank
    if form.phone and form.bank_name:
        dup = await phone_bank_duplicate_exists(
            session,
            phone=str(form.phone),
            bank_name=str(form.bank_name),
            exclude_form_id=int(form.id),
        )
        if dup:
            other = await get_user_by_id(session, int(dup.manager_id))
            other_tag = (other.manager_tag if other and other.manager_tag else "—")
            await cq.answer(
                f"❌ Такой номер уже есть для этого банка (менеджер: {other_tag}, анкета #{dup.id})",
                show_alert=True,
            )
            return

    form.status = FormStatus.PENDING
    form.team_lead_comment = None
    await cq.answer("Отправлено")
    if cq.message:
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
    await state.clear()
    if cq.message:
        shift = await get_active_shift(session, user.id)
        await _safe_edit_message(
            message=cq.message,
            text="✅ Отправлено тим‑лиду на повторную проверку.",
            reply_markup=await _build_dm_main_kb(
                session=session,
                user_id=int(form.manager_id),
                shift_active=bool(shift),
            ),
        )
    await _notify_team_leads_new_form(cq.bot, settings, session, form, user.manager_tag or "—")


@router.callback_query(F.data.startswith("dm_edit:screens:"))
async def dm_edit_screens_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    form_id = int(cq.data.split(":")[-1])
    form = await get_form(session, form_id)
    if not form:
        await state.clear()
        return
    await state.set_state(DropManagerEditStates.screenshots)
    await state.update_data(form_id=form.id)
    cnt = len(list(form.screenshots or []))
    if cq.message:
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        try:
            await cq.message.delete()
        except Exception:
            pass
        if cnt <= 0:
            await state.update_data(expected_screens=None, collected_screens=[])
            await cq.message.answer(
                "Нет скринов в анкете. Отправляйте фото:",
                reply_markup=kb_dm_edit_done_inline(form.id),
            )
        else:
            await cq.message.answer(
                "Выберите, какой скрин заменить:",
                reply_markup=kb_dm_edit_screens_inline(form.id, cnt),
            )


@router.callback_query(F.data.startswith("dm_edit:screens_done:"))
async def dm_edit_screens_done_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    parts = (cq.data or "").split(":")
    if len(parts) != 3:
        return
    form_id = int(parts[-1])
    data = await state.get_data()
    collected: list[str] = list(data.get("collected_screens") or [])
    if not collected:
        await cq.answer("Сначала отправьте фото.", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form:
        await state.clear()
        return
    form.screenshots = collected
    manager = await get_user_by_id(session, form.manager_id)
    manager_tag = (manager.manager_tag if manager and manager.manager_tag else "—")
    text = _format_form_text(form, manager_tag)

    if form.status == FormStatus.IN_PROGRESS:
        await state.set_state(DropManagerFormStates.confirm)
        await state.update_data(form_id=form.id)
        await _send_form_preview_with_keyboard(
            bot=cq.bot,
            chat_id=int(cq.message.chat.id) if cq.message else int(cq.from_user.id),
            text=text,
            photos=list(form.screenshots or []),
            reply_markup=kb_form_confirm_with_edit(form.id),
            state=state,
        )
        return

    await state.set_state(DropManagerEditStates.choose_field)
    await _send_form_preview_with_keyboard(
        bot=cq.bot,
        chat_id=int(cq.message.chat.id) if cq.message else int(cq.from_user.id),
        text=text,
        photos=list(form.screenshots or []),
        reply_markup=kb_dm_edit_actions_inline(form.id),
        state=state,
    )


@router.callback_query(F.data.startswith("dm_edit:screen_pick:"))
async def dm_edit_screen_pick_cb(cq: CallbackQuery, state: FSMContext) -> None:
    await cq.answer()
    parts = (cq.data or "").split(":")
    if len(parts) != 4:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    _, _, form_id_raw, idx_raw = parts
    await state.set_state(DropManagerEditStates.screenshot_replace)
    await state.update_data(form_id=int(form_id_raw), replace_index=int(idx_raw))
    if cq.message:
        await _set_edit_prompt_message(
            message=cq.message,
            state=state,
            text=f"Отправьте новый скрин <b>{int(idx_raw)+1}</b> (фото):",
            reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:screens:{form_id_raw}", cancel_cb="dm_edit:cancel"),
        )


@router.callback_query(F.data.startswith("dm_edit:screen_add:"))
async def dm_edit_screen_add_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    await cq.answer()
    form_id = int((cq.data or "").split(":")[-1])
    form = await get_form(session, form_id)
    if not form:
        await state.clear()
        return
    collected = list(form.screenshots or [])
    await state.set_state(DropManagerEditStates.screenshots)
    await state.update_data(form_id=form.id, expected_screens=None, collected_screens=collected)
    if cq.message:
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        try:
            await cq.message.delete()
        except Exception:
            pass
        await cq.message.answer(
            "Отправляйте фото:",
            reply_markup=kb_dm_edit_done_inline(form.id),
        )


@router.callback_query(F.data.startswith("dm_edit:field:"))
async def dm_edit_field_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    parts = cq.data.split(":")
    if len(parts) != 4:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    _, _, form_id_raw, field = parts
    form_id = int(form_id_raw)

    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return

    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        await state.clear()
        return

    await cq.answer()
    await state.update_data(form_id=form.id)
    if cq.message:
        await _cleanup_edit_preview(bot=cq.bot, chat_id=int(cq.message.chat.id), state=state)
        try:
            await cq.message.delete()
        except Exception:
            pass

    # Route to existing message handlers by setting state and asking for input
    if field == "traffic_type":
        await state.set_state(DropManagerEditStates.traffic_type)
        if cq.message:
            await _set_edit_prompt_message(
                message=cq.message,
                state=state,
                text="Выберите тип клиента:",
                reply_markup=kb_dm_traffic_type_inline(),
            )
        return

    if field == "phone":
        await state.set_state(DropManagerEditStates.phone)
        if cq.message:
            await _set_edit_prompt_message(
                message=cq.message,
                state=state,
                text="Введите номер (только номер):",
                reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
            )
        return

    if field == "bank":
        await state.set_state(DropManagerEditStates.bank_select)
        if cq.message:
            await _set_edit_prompt_message(
                message=cq.message,
                state=state,
                text="Выберите банк:",
                reply_markup=kb_dm_edit_bank_select_inline(form_id=form.id),
            )
        return

    if field == "password":
        await state.set_state(DropManagerEditStates.password)
        if cq.message:
            await _set_edit_prompt_message(
                message=cq.message,
                state=state,
                text="Введите пароль/инкод:",
                reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
            )
        return

    if field == "comment":
        await state.set_state(DropManagerEditStates.comment)
        if cq.message:
            await _set_edit_prompt_message(
                message=cq.message,
                state=state,
                text="Введите комментарий:",
                reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
            )
        return

    if field == "forwards":
        # Keep current behavior: ask to forward messages.
        if form.traffic_type == "REFERRAL":
            await state.set_state(DropManagerEditStates.referral_forward_1)
            if cq.message:
                await _set_edit_prompt_message(
                    message=cq.message,
                    state=state,
                    text="1) Перешлите сообщение клиента:",
                    reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
                )
        else:
            await state.set_state(DropManagerEditStates.direct_forward)
            if cq.message:
                await _set_edit_prompt_message(
                    message=cq.message,
                    state=state,
                    text="Перешлите сообщение клиента:",
                    reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
                )
        return

    await cq.answer("Неизвестное поле", show_alert=True)


@router.message(DropManagerEditStates.screenshot_replace, F.photo)
async def dm_edit_screen_replace_photo(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form_id = int(data["form_id"])
    idx = int(data["replace_index"])
    form = await get_form(session, form_id)
    if not form:
        await state.clear()
        return
    shots = list(form.screenshots or [])
    if idx < 0 or idx >= len(shots):
        await state.clear()
        await message.answer("Некорректный номер скрина.")
        return
    shots[idx] = message.photo[-1].file_id
    form.screenshots = shots
    manager = await get_user_by_id(session, form.manager_id)
    manager_tag = (manager.manager_tag if manager and manager.manager_tag else "—")
    text = _format_form_text(form, manager_tag)

    if form.status == FormStatus.IN_PROGRESS:
        await state.set_state(DropManagerFormStates.confirm)
        await state.update_data(form_id=form.id)
        await _send_form_preview_with_keyboard(
            bot=message.bot,
            chat_id=int(message.chat.id),
            text=text,
            photos=list(form.screenshots or []),
            reply_markup=kb_form_confirm_with_edit(form.id),
            state=state,
        )
        return

    await state.set_state(DropManagerEditStates.choose_field)
    await _send_form_preview_with_keyboard(
        bot=message.bot,
        chat_id=int(message.chat.id),
        text=text,
        photos=list(form.screenshots or []),
        reply_markup=kb_dm_edit_actions_inline(form.id),
        state=state,
    )


@router.message(DropManagerEditStates.screenshot_replace)
async def dm_edit_screen_replace_wrong(message: Message) -> None:
    await message.answer("Нужно отправить <b>фото</b>.")


@router.message(DropManagerEditStates.choose_field, F.text)
async def edit_choose_field(message: Message, session: AsyncSession, state: FSMContext, settings: Settings) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return

    choice = message.text.strip()
    if choice == "Отправить заново":
        form.status = FormStatus.PENDING
        form.team_lead_comment = None
        await state.clear()
        user = await get_user_by_tg_id(session, message.from_user.id)
        shift = await get_active_shift(session, user.id) if user else None
        await message.answer(
            "✅ Отправлено тим‑лиду на повторную проверку.",
            reply_markup=await _build_dm_main_kb(
                session=session,
                user_id=int(form.manager_id),
                shift_active=bool(shift),
            ),
        )
        # notify TL
        await _notify_team_leads_new_form(message.bot, settings, session, form, user.manager_tag or "—")
        return

    if choice == "Тип клиента":
        await state.set_state(DropManagerEditStates.traffic_type)
        await _set_edit_prompt_message(
            message=message,
            state=state,
            text="Выберите тип клиента:",
            reply_markup=kb_dm_traffic_type_inline(),
        )
        return
    if choice == "Форварды":
        if form.traffic_type == "REFERRAL":
            await state.set_state(DropManagerEditStates.referral_forward_1)
            await _set_edit_prompt_message(
                message=message,
                state=state,
                text="1) Перешлите сообщение клиента:",
                reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}"),
            )
        else:
            await state.set_state(DropManagerEditStates.direct_forward)
            await _set_edit_prompt_message(
                message=message,
                state=state,
                text="Перешлите сообщение клиента:",
                reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}"),
            )
        return
    if choice == "Номер":
        await state.set_state(DropManagerEditStates.phone)
        await _set_edit_prompt_message(
            message=message,
            state=state,
            text="Введите номер (только номер):",
            reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}"),
        )
        return
    if choice == "Банк":
        await state.set_state(DropManagerEditStates.bank_select)
        await _set_edit_prompt_message(
            message=message,
            state=state,
            text="Выберите банк:",
            reply_markup=kb_dm_edit_bank_select_inline(form_id=form.id),
        )
        return
    if choice == "Пароль":
        await state.set_state(DropManagerEditStates.password)
        await _set_edit_prompt_message(
            message=message,
            state=state,
            text="Введите пароль/инкод:",
            reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}"),
        )
        return
    if choice == "Скрины":
        bank = await get_bank_by_name(session, form.bank_name or "")
        user = await get_user_by_id(session, form.manager_id)
        src = (getattr(user, "manager_source", None) or "").upper() if user else ""
        required = None
        if bank:
            if src == "FB":
                required = getattr(bank, "required_screens_fb", None)
            elif src == "TG":
                required = getattr(bank, "required_screens_tg", None)
            if required is None:
                required = getattr(bank, "required_screens", None)
        await state.update_data(expected_screens=required, collected_screens=[])
        await state.set_state(DropManagerEditStates.screenshots)
        if required and required > 0:
            await _set_edit_prompt_message(
                message=message,
                state=state,
                text=f"Нужно <b>{required}</b> фото. Отправьте скрин 1/{required}:",
                reply_markup=kb_dm_edit_done_inline(form.id),
            )
        else:
            await _set_edit_prompt_message(
                message=message,
                state=state,
                text="Отправляйте фото:",
                reply_markup=kb_dm_edit_done_inline(form.id),
            )
        return
    if choice == "Комментарий":
        await state.set_state(DropManagerEditStates.comment)
        await _set_edit_prompt_message(
            message=message,
            state=state,
            text="Введите комментарий:",
            reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}"),
        )
        return

    await message.answer("Выберите пункт кнопкой.")


@router.message(DropManagerEditStates.traffic_type, F.text)
async def edit_traffic(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    if message.text in {"Прямой", "Прямой трафик"}:
        form.traffic_type = "DIRECT"
        form.referral_user = None
        await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)
        return
    if message.text == "Сарафан":
        form.traffic_type = "REFERRAL"
        await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)
        return
    await message.answer("Выберите кнопкой.")


@router.message(DropManagerEditStates.direct_forward)
async def edit_direct_forward(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.direct_user = extract_forward_payload(message)
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


@router.message(DropManagerEditStates.referral_forward_1)
async def edit_ref_forward_1(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.direct_user = extract_forward_payload(message)
    await state.set_state(DropManagerEditStates.referral_forward_2)
    await message.answer("2) Перешлите сообщение того, кто привёл:")


@router.message(DropManagerEditStates.referral_forward_2)
async def edit_ref_forward_2(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.referral_user = extract_forward_payload(message)
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


@router.message(DropManagerEditStates.phone, F.text)
async def edit_phone(message: Message, session: AsyncSession, state: FSMContext) -> None:
    if not is_valid_phone(message.text):
        await message.answer("Только номер. Пример: <code>944567892</code> или <code>+380991112233</code>")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.phone = normalize_phone(message.text)
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


@router.message(DropManagerEditStates.bank_select, F.text)
async def edit_bank_select(message: Message, session: AsyncSession, state: FSMContext) -> None:
    await message.answer("Выберите банк кнопкой.")


@router.message(DropManagerEditStates.bank_custom, F.text)
async def edit_bank_custom(message: Message, session: AsyncSession, state: FSMContext) -> None:
    name = message.text.strip()
    if not name or len(name) > 64:
        await message.answer("Введите корректное название банка:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.bank_name = name
    if not await get_bank_by_name(session, name):
        await create_bank(session, name)
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


@router.callback_query(F.data.startswith("dm_edit:bank_pick:"))
async def dm_edit_bank_pick_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    parts = (cq.data or "").split(":", 3)
    if len(parts) != 4:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    _, _, form_id_raw, bank_name = parts
    try:
        form_id = int(form_id_raw)
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return

    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    if bank_name not in DEFAULT_BANKS:
        await cq.answer("Некорректный банк", show_alert=True)
        return

    form.bank_name = bank_name
    await cq.answer("Сохранено")

    await state.set_state(DropManagerEditStates.choose_field)
    await state.update_data(form_id=form.id)
    manager_tag = user.manager_tag or "—"
    text = _format_form_text(form, manager_tag)
    photos = list(form.screenshots or [])
    await _send_form_preview_with_keyboard(
        bot=cq.bot,
        chat_id=int(cq.message.chat.id) if cq.message else int(cq.from_user.id),
        text=text,
        photos=photos,
        reply_markup=kb_dm_edit_actions_inline(form.id),
        state=state,
    )


@router.callback_query(F.data.startswith("dm_edit:bank_custom:"))
async def dm_edit_bank_custom_prompt_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    parts = (cq.data or "").split(":")
    if len(parts) != 3:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return
    try:
        form_id = int(parts[-1])
    except Exception:
        await cq.answer("Некорректная кнопка", show_alert=True)
        return

    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    await cq.answer()
    await state.set_state(DropManagerEditStates.bank_custom)
    await state.update_data(form_id=form.id)
    if cq.message:
        await _set_edit_prompt_message(
            message=cq.message,
            state=state,
            text="Введите название банка:",
            reply_markup=kb_dm_back_cancel_inline(back_cb=f"dm_edit:back:{form.id}", cancel_cb="dm_edit:cancel"),
        )


@router.message(DropManagerEditStates.password, F.text)
async def edit_password(message: Message, session: AsyncSession, state: FSMContext) -> None:
    pwd = (message.text or "").strip()
    if not pwd:
        await message.answer("Введите пароль/инкод:")
        return
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.password = pwd
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


@router.message(DropManagerEditStates.screenshots, F.photo)
async def edit_screens_add(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    expected = data.get("expected_screens")
    collected: list[str] = list(data.get("collected_screens") or [])
    media_group_id = getattr(message, "media_group_id", None)
    if media_group_id:
        key = (int(message.chat.id), str(media_group_id))
        _album_counts[key] = _album_counts.get(key, 0) + 1
    if len(collected) < 20:
        collected.append(message.photo[-1].file_id)
    await state.update_data(collected_screens=collected)

    if expected and expected > 0:
        if len(collected) < expected:
            if media_group_id:
                _schedule_album_ack(
                    bot=message.bot,
                    chat_id=int(message.chat.id),
                    media_group_id=str(media_group_id),
                    accepted_total=len(collected),
                    expected=int(expected),
                    reply_markup=kb_dm_edit_done_inline(int(data["form_id"])),
                )
                return
            await _upsert_prompt_message(
                message=message,
                state=state,
                state_key="edit_screens_prompt_msg_id",
                text=f"Отправьте скрин {len(collected)+1}/{expected}:",
                reply_markup=kb_dm_edit_done_inline(int(data["form_id"])),
            )
            return
        form = await get_form(session, int(data["form_id"]))
        if not form:
            await state.clear()
            return
        form.screenshots = collected
        await state.set_state(DropManagerEditStates.choose_field)
        try:
            manager = await get_user_by_id(session, form.manager_id)
            manager_tag = (manager.manager_tag if manager and manager.manager_tag else "—")
            text = _format_form_text(form, manager_tag)
            await message.answer(text, reply_markup=kb_dm_edit_actions_inline(form.id))
        except TelegramNetworkError:
            return
        return

    if media_group_id:
        _schedule_album_ack(
            bot=message.bot,
            chat_id=int(message.chat.id),
            media_group_id=str(media_group_id),
            accepted_total=len(collected),
            expected=None,
            reply_markup=kb_dm_edit_done_inline(int(data["form_id"])),
        )

    if len(collected) >= 20:
        form = await get_form(session, int(data["form_id"]))
        if not form:
            await state.clear()
            return
        form.screenshots = collected
        await state.set_state(DropManagerEditStates.choose_field)
        try:
            manager = await get_user_by_id(session, form.manager_id)
            manager_tag = (manager.manager_tag if manager and manager.manager_tag else "—")
            text = _format_form_text(form, manager_tag)
            await message.answer(text, reply_markup=kb_dm_edit_actions_inline(form.id))
        except TelegramNetworkError:
            return


@router.message(DropManagerEditStates.comment, F.text)
async def edit_comment(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    form.comment = message.text.strip()
    await _after_dm_edit_show_form(message=message, session=session, state=state, form=form)


# Back navigation handlers for form creation
@router.message(DropManagerFormStates.traffic_type, F.text == "Назад")
async def form_back_to_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Создание анкеты отменено.")

@router.message(DropManagerFormStates.direct_forward, F.text == "Назад")
async def form_back_to_traffic_type(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.traffic_type)
    await message.answer("Выберите тип клиента:", reply_markup=kb_dm_traffic_type_inline())

@router.message(DropManagerFormStates.referral_forward_1, F.text == "Назад")
async def form_back_to_traffic_type_from_ref1(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.traffic_type)
    await message.answer("Выберите тип клиента:", reply_markup=kb_dm_traffic_type_inline())

@router.message(DropManagerFormStates.referral_forward_2, F.text == "Назад")
async def form_back_to_referral_forward_1(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.referral_forward_1)
    await message.answer(
        "1) Перешлите сообщение клиента (на кого анкета):",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
    )

@router.message(DropManagerFormStates.phone, F.text == "Назад")
async def form_back_to_previous_forward(message: Message, session: AsyncSession, state: FSMContext) -> None:
    data = await state.get_data()
    form = await get_form(session, int(data["form_id"]))
    if not form:
        await state.clear()
        return
    
    if form.traffic_type == "DIRECT":
        await state.set_state(DropManagerFormStates.direct_forward)
        await message.answer(
            "Перешлите сообщение клиента (форвард):",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_traffic"),
        )
    elif form.traffic_type == "REFERRAL":
        await state.set_state(DropManagerFormStates.referral_forward_2)
        await message.answer(
            "2) Перешлите сообщение того, кто привёл:",
            reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_ref1"),
        )

@router.message(DropManagerFormStates.bank_select, F.text == "Назад")
async def form_back_to_phone(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.phone)
    await message.answer(
        "Напишите номер и перешлите его в бота.\n"
        "Сообщение должно содержать <b>только номер</b> и ничего больше:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_forward")
    )

@router.message(DropManagerFormStates.bank_custom, F.text == "Назад")
async def form_back_to_bank_select(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.bank_select)
    await message.answer("Выберите банк:", reply_markup=kb_dm_bank_select_inline())

@router.message(DropManagerFormStates.password, F.text == "Назад")
async def form_back_to_bank_select_from_password(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.bank_select)
    await message.answer("Выберите банк:", reply_markup=kb_dm_bank_select_inline())

@router.message(DropManagerFormStates.screenshots, F.text == "Назад")
async def form_back_to_password(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.password)
    await message.answer(
        "Введите пароль/инкод:",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_bank_select"),
    )

@router.message(DropManagerFormStates.comment, F.text == "Назад")
async def form_back_to_screenshots(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.screenshots)
    await message.answer("Отправляйте фото:", reply_markup=kb_dm_done_inline())

@router.message(DropManagerFormStates.confirm, F.text == "Назад")
async def form_back_to_comment(message: Message, state: FSMContext) -> None:
    await state.set_state(DropManagerFormStates.comment)
    await message.answer(
        "Добавьте комментарий (необязательно):",
        reply_markup=kb_dm_back_cancel_inline(back_cb="dm:back_to_screens"),
    )


# Fallback: capture manager tag (must be last to avoid intercepting other text handlers)
@router.message(F.text)
async def capture_manager_tag_if_needed(message: Message, session: AsyncSession) -> None:
    if not message.from_user or not message.text:
        return
    if message.text.startswith("/"):
        return
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    if user.manager_tag:
        return
    tag = message.text.strip()
    if not tag or len(tag) > 64:
        await message.answer("Тег слишком длинный/пустой. Введите тег ещё раз:")
        return
    user.manager_tag = tag
    shift = await get_active_shift(session, user.id)
    # Ask source/category once
    if not user.manager_source:
        await message.answer(
            f"✅ Сохранено. Вы Дроп‑Менеджер — ваш никнейм <b>{user.manager_tag}</b>.\n\nВыберите источник:",
            reply_markup=kb_dm_source_pick_inline(),
        )
        return
    await message.answer(
        f"✅ Сохранено. Вы Дроп‑Менеджер — ваш никнейм <b>{user.manager_tag}</b>.",
        reply_markup=await _build_dm_main_kb(
            session=session,
            user_id=int(user.id),
            shift_active=bool(shift),
        ),
    )


@router.callback_query(F.data.startswith("dm:src:"))
async def dm_pick_source_cb(cq: CallbackQuery, session: AsyncSession) -> None:
    if not cq.from_user:
        return
    src = cq.data.split(":")[-1].upper()
    if src not in {"TG", "FB"}:
        await cq.answer("Некорректный источник", show_alert=True)
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return
    user.manager_source = src
    shift = await get_active_shift(session, user.id)
    await cq.answer("Сохранено")
    if cq.message:
        await cq.message.edit_text(
            f"✅ Сохранено. Источник: <b>{src}</b>\n\nГлавное меню:",
            reply_markup=await _build_dm_main_kb(
                session=session,
                user_id=int(user.id),
                shift_active=bool(shift),
            ),
        )


def _format_rejected_form_summary(form) -> str:
    """Format a rejected form summary for the list."""
    traffic = "Прямой" if form.traffic_type == "DIRECT" else "Сарафан" if form.traffic_type == "REFERRAL" else "—"
    
    return (
        f"❌ <b>ID: {form.id}</b>\n"
        f"   🏦 Банк: {form.bank_name or '—'}\n"
        f"   📊 Тип клиента: {traffic}\n"
        f"   📞 Телефон: {form.phone or '—'}\n"
        f"   📅 Создана: {form.created_at.strftime('%d.%m.%Y %H:%M')}\n"
        f"   💬 Комментарий: {form.team_lead_comment[:50]}{'...' if len(form.team_lead_comment or '') > 50 else ''}"
    )


def _format_rejected_form_details(form) -> str:
    """Format detailed rejected form information."""
    traffic = "Прямой" if form.traffic_type == "DIRECT" else "Сарафан" if form.traffic_type == "REFERRAL" else "—"
    
    details = (
        f"❌ <b>ОТКЛОНЕННАЯ АНКЕТА #{form.id}</b>\n\n"
        f"📊 <b>Информация:</b>\n"
        f"Тип клиента: <b>{traffic}</b>\n"
        f"Банк: <b>{form.bank_name or '—'}</b>\n"
        f"Телефон: <code>{form.phone or '—'}</code>\n"
        f"Пароль: <code>{form.password or '—'}</code>\n"
        f"Скриншоты: <b>{len(form.screenshots or [])}</b> шт.\n"
        f"Комментарий: {form.comment or '—'}\n\n"
        f"📅 <b>Даты:</b>\n"
        f"Создана: {form.created_at.strftime('%d.%m.%Y %H:%M')}\n"
        f"Обновлена: {form.updated_at.strftime('%d.%m.%Y %H:%M')}\n\n"
        f"💬 <b>Комментарий тим-лида:</b>\n{form.team_lead_comment or '—'}"
    )
    
    return details


@router.message(F.text == "Неапрувнутые анкеты")
async def rejected_forms_start(message: Message, session: AsyncSession, state: FSMContext) -> None:
    # Ignore group messages
    if message.chat.type in ['group', 'supergroup']:
        return
    if not message.from_user:
        return
    
    user = await get_user_by_tg_id(session, message.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return
    
    await state.clear()
    await dm_rejected_cb(message, session, state)


@router.callback_query(F.data == "dm:rejected")
async def dm_rejected_cb(cq_or_msg: Message | CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    u = cq_or_msg.from_user if isinstance(cq_or_msg, CallbackQuery) else cq_or_msg.from_user
    if not u:
        return
    user = await get_user_by_tg_id(session, u.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        return

    rejected_forms = await list_rejected_forms_by_user_id(session, user.id)
    if not rejected_forms:
        text = "У вас нет неапрувнутых анкет"
        if isinstance(cq_or_msg, CallbackQuery):
            await cq_or_msg.answer(text, show_alert=True)
            if cq_or_msg.message:
                try:
                    await cq_or_msg.message.answer(text, reply_markup=kb_dm_back_to_menu_inline())
                except Exception:
                    pass
                try:
                    await cq_or_msg.message.delete()
                except Exception:
                    pass
        else:
            await cq_or_msg.answer(text, reply_markup=kb_dm_back_to_menu_inline())
        return

    await state.clear()
    await state.set_state(DropManagerRejectedStates.view_list)
    await state.update_data(forms=[{"id": int(f.id)} for f in rejected_forms])

    header = f"❌ <b>Отклоненные анкеты</b>\n\nВсего: <b>{len(rejected_forms)}</b>\n\nВыберите анкету:"
    kb = _kb_dm_rejected_list_inline(rejected_forms).as_markup()

    if isinstance(cq_or_msg, CallbackQuery):
        await cq_or_msg.answer()
        if cq_or_msg.message:
            try:
                await cq_or_msg.message.answer(header, reply_markup=kb)
            except Exception:
                pass
            try:
                await cq_or_msg.message.delete()
            except Exception:
                pass
    else:
        await cq_or_msg.answer(header, reply_markup=kb)


@router.callback_query(F.data.startswith("dm:rej:"))
async def dm_rejected_open_cb(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or user.role != UserRole.DROP_MANAGER:
        await cq.answer("Нет прав", show_alert=True)
        return

    form_id = int(cq.data.split(":")[-1])
    form = await get_form(session, form_id)
    if not form or form.manager_id != user.id or form.status != FormStatus.REJECTED:
        await cq.answer("Анкета не найдена", show_alert=True)
        return

    await cq.answer()
    await state.clear()
    await edit_open(cq, FormEditCb(action="open", form_id=form_id), session, state)





@router.callback_query(F.data.startswith("drop_edit_form:"))
async def edit_rejected_form(cq: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    if not cq.from_user:
        return
    
    form_id = int((cq.data or "").split(":")[-1])
    form = await get_form(session, form_id)
    
    if not form:
        await cq.answer("Анкета не найдена", show_alert=True)
        return
    
    user = await get_user_by_tg_id(session, cq.from_user.id)
    if not user or form.manager_id != user.id:
        await cq.answer("Нет прав", show_alert=True)
        return
    
    await cq.answer()
    await state.clear()
    
    # Перенаправляем в существующую систему редактирования
    await state.set_state(DropManagerEditStates.choose_field)
    await state.update_data(form_id=form_id)
    
    if cq.message:
        await cq.message.edit_text("Выберите что хотите изменить:", reply_markup=kb_dm_edit_actions_inline(form_id))


